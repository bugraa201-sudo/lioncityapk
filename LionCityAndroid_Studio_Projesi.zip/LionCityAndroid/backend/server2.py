import asyncio
import json
import os
import random
import time
import uuid
from aiohttp import web

passengers = {}  
connected_drivers = {}  
DRIVER_FILE = "drivers.txt"

# drivers.txt dosyası yoksa otomatik oluştur
if not os.path.exists(DRIVER_FILE):
    with open(DRIVER_FILE, "w", encoding="utf-8") as f:
        f.write("05321234567 : 1234 : Ahmet Yılmaz\n")
        f.write("05559876543 : 5678 : Mehmet Demir\n")
        f.write("05421112233 : 4321 : Caner Kaya\n")

def load_drivers():
    drivers = {}
    if os.path.exists(DRIVER_FILE):
        with open(DRIVER_FILE, "r", encoding="utf-8") as f:
            for line in f:
                if ":" in line:
                    parts = [p.strip() for p in line.strip().split(":")]
                    if len(parts) >= 3:
                        drivers[parts[0]] = {"code": parts[1], "name": parts[2]}
    return drivers

HTML_CONTENT = """<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>Lion City - Sürüş Platformu</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; -webkit-tap-highlight-color: transparent; }
        body, html { width: 100%; height: 100%; overflow: hidden; background-color: #f0f2f5; color: #111; }
        
        #app { display: flex; flex-direction: column; height: 100vh; height: 100dvh; width: 100vw; position: relative; }
        #map { flex: 1; width: 100%; height: 100%; z-index: 1; background: #e5e3df; }

        header {
            position: absolute; top: 12px; left: 12px; right: 12px; z-index: 1000;
            background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(12px);
            border: 1px solid rgba(0, 0, 0, 0.1); border-radius: 14px;
            padding: 8px 12px; display: flex; justify-content: space-between; align-items: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.15);
        }
        .brand-container { display: flex; flex-direction: column; gap: 2px; }
        .brand { font-size: 0.95rem; font-weight: 800; color: #111; display: flex; align-items: center; gap: 6px; }
        .brand-tag { background: #ffb300; color: #000; font-size: 0.55rem; padding: 2px 6px; border-radius: 6px; font-weight: 900; }
        
        .live-stats { font-size: 0.65rem; color: #555; font-weight: 600; display: flex; gap: 8px; }
        .stat-item span { font-weight: 800; color: #111; }

        .mode-selector { display: flex; background: rgba(0,0,0,0.05); padding: 2px; border-radius: 8px; border: 1px solid rgba(0,0,0,0.05); }
        .mode-btn { border: none; background: transparent; color: #666; padding: 5px 10px; font-size: 0.75rem; font-weight: 700; border-radius: 6px; cursor: pointer; transition: all 0.2s; }
        .mode-btn.active-p { background: #ffb300; color: #000; }
        .mode-btn.active-d { background: #29b6f6; color: #fff; }

        .bottom-sheet {
            position: absolute; bottom: 85px; left: 12px; right: 12px; z-index: 1000;
            background: #ffffff; border-radius: 16px;
            padding: 14px; border: 1px solid rgba(0,0,0,0.1);
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            max-height: 48vh; overflow-y: auto;
            -webkit-overflow-scrolling: touch; color: #111;
            padding-bottom: calc(12px + env(safe-area-inset-bottom));
        }
        @media (min-width: 768px) {
            .bottom-sheet { top: auto; bottom: 25px; left: 20px; right: auto; width: 380px; max-height: 80vh; }
        }

        .action-btn {
            width: 100%; background: #ffb300; color: #000; border: none; padding: 12px;
            font-size: 0.9rem; font-weight: 800; border-radius: 10px; cursor: pointer; margin-top: 8px;
            box-shadow: 0 4px 12px rgba(255, 179, 0, 0.3);
            pointer-events: auto; z-index: 2000; position: relative;
            -webkit-appearance: none; text-align: center; text-decoration: none; display: block;
        }
        .action-btn:disabled { opacity: 0.6; cursor: default; }
        .action-btn.driver-btn { background: #29b6f6; color: #fff; box-shadow: 0 4px 12px rgba(41, 182, 246, 0.3); }
        .action-btn.danger-btn { background: #ff5252; color: #fff; box-shadow: 0 4px 12px rgba(255, 82, 82, 0.4); }
        .action-btn.maps-btn { background: #34a853; color: #fff; box-shadow: 0 4px 12px rgba(52, 168, 83, 0.3); }
        .action-btn.logout-btn { background: #78909c; color: #fff; margin-top: 6px; box-shadow: none; font-size: 0.8rem; padding: 8px; }
        
        .reset-btn { 
            background: transparent; color: #888; border: none; font-size: 0.75rem; 
            font-weight: 600; margin-top: 8px; width: 100%; text-align: center; cursor: pointer;
            padding: 4px; text-decoration: underline;
        }

        .btn-group { display: flex; gap: 8px; margin-top: 8px; padding-bottom: 3px; }

        .info-card { background: #f8f9fa; border-radius: 8px; padding: 8px 10px; margin-top: 6px; border: 1px solid rgba(0,0,0,0.05); }
        .info-title { font-size: 0.68rem; color: #666; text-transform: uppercase; font-weight: 700; margin-bottom: 2px; }
        .info-val { font-size: 0.9rem; font-weight: 700; color: #111; margin-top: 2px; }
        
        .input-box {
            width: 100%; background: #fff; border: 1px solid #ccc;
            color: #111; padding: 9px 10px; border-radius: 6px; font-size: 0.88rem; outline: none; margin-top: 3px;
            pointer-events: auto; z-index: 2000; position: relative;
        }
        .input-box:focus { border-color: #ffb300; }

        .status-badge { display: inline-block; padding: 3px 8px; border-radius: 15px; font-size: 0.62rem; font-weight: 700; margin-bottom: 4px; }
        .st-waiting { background: rgba(255, 179, 0, 0.2); color: #b78103; }
        .st-matched { background: rgba(0, 230, 118, 0.2); color: #008736; }
        .st-inride { background: rgba(41, 182, 246, 0.2); color: #0288d1; }
        .st-offline { background: rgba(120, 144, 156, 0.2); color: #546e7a; }

        .match-card { border: 1px solid #00c853; background: #e8f5e9; }
        .match-card.arrived { background: #00c853; border-color: #00a844; }
        .match-card.arrived .info-title, .match-card.arrived .info-val, .match-card.arrived .code-label { color: #fff !important; }
        .code-label { font-size: 0.68rem; color: #555; font-weight: 700; text-transform: uppercase; margin-top: 6px; }
        .code-big { font-size: 2rem; font-weight: 900; letter-spacing: 8px; text-align: center; color: #111; background: rgba(255,255,255,0.85); border-radius: 8px; padding: 4px 0; margin-top: 2px; }

        .pickup-marker { background: #29b6f6; border: 3px solid #fff; border-radius: 50%; box-shadow: 0 0 10px #29b6f6; }
        .dropoff-marker { background: #16a34a; border: 3px solid #fff; border-radius: 50%; box-shadow: 0 0 10px #16a34a; }
        .driver-marker { background: #ff9800; border: 3px solid #fff; border-radius: 50%; box-shadow: 0 0 10px #ff9800; }
        .radar-driver-marker { background: #ff9800; border: 2px solid #fff; border-radius: 50%; box-shadow: 0 0 8px rgba(255,152,0,0.8); }
        .route-distance-label { background: rgba(255,255,255,0.95); border: 1px solid #333; color: #111; border-radius: 5px; font-weight: 800; padding: 3px 6px; box-shadow: 0 1px 5px rgba(0,0,0,.25); }

        .toggle-container { display: flex; align-items: center; justify-content: space-between; margin-top: 6px; background: #fff; padding: 6px 10px; border-radius: 8px; border: 1px solid #ddd; }
        .toggle-switch { position: relative; display: inline-block; width: 44px; height: 24px; }
        .toggle-switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .3s; border-radius: 24px; }
        .slider:before { position: absolute; content: ""; height: 18px; width: 18px; left: 3px; bottom: 3px; background-color: white; transition: .3s; border-radius: 50%; }
        input:checked + .slider { background-color: #00c853; }
        input:checked + .slider:before { transform: translateX(20px); }

        .rating-modal-backdrop {
            position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
            background: rgba(0,0,0,0.6); backdrop-filter: blur(4px); z-index: 9999;
            display: flex; justify-content: center; align-items: center; padding: 20px;
        }
        .rating-card {
            background: #fff; width: 100%; max-width: 350px; border-radius: 20px; padding: 20px;
            text-align: center; box-shadow: 0 10px 30px rgba(0,0,0,0.3); animation: popIn 0.3s ease;
        }
        @keyframes popIn { from { transform: scale(0.8); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        .star-rating { display: flex; justify-content: center; gap: 8px; margin: 15px 0; font-size: 2rem; cursor: pointer; }
        .star { color: #ccc; transition: color 0.2s; }
        .star.active { color: #ffb300; }

        .menu-toggle{width:34px;height:34px;border:0;background:#f2f3f5;border-radius:9px;display:flex;flex-direction:column;justify-content:center;align-items:center;gap:4px;cursor:pointer;flex-shrink:0}.menu-toggle span{width:18px;height:2px;background:#202124;border-radius:2px;display:block}header .brand-container{margin-right:auto;margin-left:9px}.profile-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.42);z-index:4000}.profile-drawer{position:fixed;z-index:4001;top:0;left:0;bottom:0;width:min(390px,88vw);background:#fff;box-shadow:8px 0 28px rgba(0,0,0,.22);padding:18px 14px calc(20px + env(safe-area-inset-bottom));overflow-y:auto;transform:translateX(-105%);transition:transform .22s ease}.profile-drawer.open{transform:translateX(0)}.profile-drawer-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;padding-bottom:12px;border-bottom:1px solid #e5e7eb;font-size:1.05rem}.profile-close{border:0;background:#f1f3f4;border-radius:50%;width:34px;height:34px;font-size:24px;line-height:1;cursor:pointer}.profile-drawer .info-card{margin-top:10px}

        .chat-box { margin-top:10px; border:1px solid #d9dee5; border-radius:10px; padding:9px; background:#fff; }
        .chat-head { display:flex; justify-content:space-between; align-items:center; font-size:.78rem; font-weight:800; margin-bottom:7px; }
        .chat-live { color:#168bdb; font-size:.65rem; }
        .chat-messages { height:150px; overflow-y:auto; background:#f5f7fa; border-radius:8px; padding:7px; display:flex; flex-direction:column; gap:6px; }
        .chat-message { max-width:88%; padding:7px 9px; border-radius:10px; background:#e8eef5; font-size:.78rem; line-height:1.35; overflow-wrap:anywhere; }
        .chat-message.mine { align-self:flex-end; background:#fff0c2; }
        .chat-message .chat-time { display:block; color:#68717c; font-size:.58rem; margin-top:3px; text-align:right; }
        .chat-quick { display:flex; flex-wrap:wrap; gap:5px; margin:7px 0; }
        .chat-quick button { border:1px solid #d5dbe2; border-radius:15px; background:#f8fafc; padding:6px 8px; font-size:.67rem; cursor:pointer; }
        .chat-compose { display:flex; gap:6px; margin-top:6px; }
        .chat-compose input { flex:1; min-width:0; margin:0; }
        .chat-compose button { border:0; border-radius:7px; padding:0 13px; background:#ffb300; font-weight:800; }
        .driver-chat .chat-compose button { background:#29b6f6; color:white; }
        .menu-tools{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin:10px 0 12px}.menu-item{border:1px solid #dfe3e8;background:#f7f8fa;color:#202124;border-radius:9px;padding:10px 8px;text-align:left;font-size:.78rem;font-weight:700;cursor:pointer}
        body.dark-mode, body.dark-mode html{background:#10151d;color:#e7edf5}
        body.dark-mode header,body.dark-mode .bottom-sheet,body.dark-mode .profile-drawer,body.dark-mode .rating-card{background:#1b2430!important;color:#e7edf5!important;border-color:#354253!important}
        body.dark-mode .brand,body.dark-mode .stat-item span,body.dark-mode .info-val,body.dark-mode .chat-head{color:#e7edf5!important}
        body.dark-mode .live-stats,body.dark-mode .info-title,body.dark-mode .code-label{color:#aebaca!important}
        body.dark-mode .info-card,body.dark-mode .toggle-container,body.dark-mode .chat-box{background:#222e3c!important;color:#e7edf5!important;border-color:#3a4a5d!important}
        body.dark-mode .input-box,body.dark-mode .chat-messages{background:#121a24!important;color:#e7edf5!important;border-color:#46566a!important}
        body.dark-mode .chat-message{background:#304052;color:#f3f6fa}body.dark-mode .chat-message.mine{background:#594719;color:#fff4d2}
        body.dark-mode .chat-quick button,body.dark-mode .menu-item,body.dark-mode .profile-close{background:#2c3949!important;color:#e7edf5!important;border-color:#46566a!important}
        body.dark-mode .mode-selector{background:#111923;border-color:#354253}body.dark-mode .mode-btn{color:#c5cfdb}
        body.dark-mode .match-card{background:#173a2b!important;border-color:#16894b!important}body.dark-mode .match-card.arrived{background:#087b3a!important}
        body.dark-mode .st-waiting{color:#ffd166}body.dark-mode .route-distance-label{background:#1b2430;color:#fff;border-color:#667}

        .announcement-overlay{position:fixed;inset:0;z-index:5000;background:rgba(8,15,25,.62);display:flex;align-items:center;justify-content:center;padding:18px}
        .announcement-card{width:min(460px,100%);max-height:82vh;overflow:auto;background:#fff;color:#172033;border-radius:16px;padding:20px;box-shadow:0 18px 60px #0005}
        .announcement-card h3{margin:0 0 10px;font-size:1.15rem}.announcement-card p{white-space:pre-wrap;line-height:1.55;margin:0 0 16px}
        .announcement-actions{display:flex;gap:8px;justify-content:flex-end}.announcement-actions button{border:0;border-radius:9px;padding:10px 14px;font-weight:800;cursor:pointer}
        .announcement-primary{background:#f5b323;color:#171717}.announcement-secondary{background:#e8edf3;color:#172033}
        .announcement-row{padding:12px 0;border-bottom:1px solid #e5e9ef}.announcement-row:last-child{border-bottom:0}
        body.dark-mode .announcement-card{background:#1b2430;color:#e7edf5}body.dark-mode .announcement-secondary{background:#344255;color:#e7edf5}
        .hidden { display: none !important; }
    </style>
</head>
<body>

<div id="app">
    <header>
        <button id="menuToggle" class="menu-toggle" aria-label="Profilleri aç" onclick="toggleProfileMenu()" type="button"><span></span><span></span><span></span></button>
        <div class="brand-container">
            <div class="brand">LION <span class="brand-tag">CITY</span></div>
            <div class="live-stats">
                <span class="stat-item">Yolcu: <span id="statPassengers">0</span></span>
                <span class="stat-item">•</span>
                <span class="stat-item">Sürücü: <span id="statDrivers">0</span></span>
            </div>
        </div>
        <div class="mode-selector">
            <button id="pModeBtn" class="mode-btn active-p" onclick="setMode('passenger')">Yolcu</button>
            <button id="dModeBtn" class="mode-btn" onclick="setMode('driver')">Sürücü</button>
        </div>
    </header>
    <div id="profileBackdrop" class="profile-backdrop hidden" onclick="toggleProfileMenu(false)"></div>
    <aside id="profileDrawer" class="profile-drawer" aria-hidden="true">
      <div class="profile-drawer-head"><div><b>Hesabım</b><div id="profileDrawerSubtitle" class="info-title">Lion City profilleri</div></div><button type="button" class="profile-close" onclick="toggleProfileMenu(false)">×</button></div>
      <div class="menu-tools">
        <button type="button" class="menu-item" onclick="setMode('passenger');toggleProfileMenu(false)">🚕 Yolcu paneli</button>
        <button type="button" class="menu-item" onclick="setMode('driver');toggleProfileMenu(false)">🚗 Sürücü paneli</button>
        <button type="button" class="menu-item" onclick="map.setView(userLocation || map.getCenter(), 15);toggleProfileMenu(false)">📍 Haritaya dön</button>
        <button type="button" class="menu-item" id="themeToggleBtn" onclick="toggleDarkMode()">🌙 Koyu modu aç</button>
        <button type="button" class="menu-item" onclick="openAnnouncements();toggleProfileMenu(false)">📢 Duyurular <span id="announcementUnreadCount"></span></button>
        <button type="button" class="menu-item" onclick="window.open('/admin', '_blank', 'noopener')">🛠️ Yönetici girişi</button>
      </div>
      <div id="passengerAuthBox" class="info-card">
        <div class="info-title">Yolcu hesabı</div><div id="passengerAuthModeLabel" class="info-val">Telefon numarasıyla yalnızca bir kez kayıt olun.</div>
        <div id="passengerRegisterFields"><input id="passengerFirstName" class="input-box" maxlength="40" autocomplete="given-name" placeholder="Adınız"><input id="passengerLastName" class="input-box" maxlength="40" autocomplete="family-name" placeholder="Soyadınız"></div>
        <input id="passengerAuthPhone" class="input-box" type="tel" maxlength="20" autocomplete="tel" placeholder="Telefon numarası"><input id="passengerAuthPassword" class="input-box" type="password" maxlength="128" autocomplete="current-password" placeholder="Şifre (en az 8 karakter)">
        <button id="passengerAuthSubmit" class="action-btn" onclick="submitPassengerAuth()">KAYIT OL</button><button id="passengerAuthSwitch" class="reset-btn" onclick="switchPassengerAuthMode()">Zaten hesabım var · Giriş yap</button><div id="passengerAuthMessage" class="info-title" style="margin-top:8px"></div>
      </div>
      <div id="passengerProfileCard" class="info-card hidden"><div class="info-title">Yolcu Profilim</div><div class="info-val" id="passengerProfileName">Yolcu</div><div class="info-title" id="passengerProfilePhone"></div><div class="info-card" style="background:#fff8e1;margin-top:9px"><div class="info-title">Yolcunun Genel Puanı</div><div class="info-val" id="passengerProfileAverage" style="font-size:1.25rem;color:#a66a00;margin-top:4px">★ -- / 5</div><div class="info-title" id="passengerProfileCount">Henüz değerlendirme yok</div></div><div class="info-title" style="margin-top:12px">Geçmiş Yolculuklar ve Değerlendirmeler</div><div id="passengerHistory" class="info-val" style="font-size:.78rem;font-weight:400">Yükleniyor...</div><button class="action-btn logout-btn" onclick="logoutPassenger()">HESAPTAN ÇIKIŞ</button></div>
      <div id="driverProfileCard" class="info-card hidden"><div class="info-title">Sürücü Profilim</div><div class="info-val" id="driverProfileName">Sürücü</div><div class="info-title" id="driverProfilePhone"></div><div class="info-val" id="driverRatingValue">★ -- / 5</div><div class="info-title" id="driverRatingCount">Henüz değerlendirme yok</div><div class="info-title" style="margin-top:12px">Geçmiş Yolculuklar ve Yolcu Değerlendirmeleri</div><div id="driverHistory" class="info-val" style="font-size:.78rem;font-weight:400">Yükleniyor...</div></div>
    </aside>
    <div id="map"></div>

    <div class="bottom-sheet" id="sheetContent">
        <!-- Yolcu Paneli -->
        <div id="passengerPanel">
            <div class="status-badge st-waiting" id="pStatus">Konum Hazır</div>
            <div id="passengerActiveRideBox">
                <div class="info-card">
                    <div class="info-title">Kalkış Noktası (Müşteri Konumu)</div>
                    <input type="text" id="pickupInput" class="input-box" placeholder="Adres yazın..." onchange="searchAddress(this.value, 'pickup')">
                </div>
                <div class="info-card">
                    <div class="info-title">Varış Noktası (Gideceğiniz Yer)</div>
                    <input type="text" id="dropoffInput" class="input-box" placeholder="Adres yazın veya haritaya tıklayın" onchange="searchAddress(this.value, 'dropoff')">
                </div>
            </div>

            <!-- EŞLEŞME KARTI (SÜRÜCÜ YOLDA / KONUMDA İKEN KODU GÖSTERİR) -->
            <div id="passengerMatchCard" class="hidden info-card match-card">
                <div class="info-title" id="matchTitle" style="color:#008736; font-weight:800;">EŞLEŞTİ - SÜRÜCÜ YOLDA</div>
                <div class="info-val" id="matchDriverName" style="font-size:0.95rem;">Sürücü: --</div>
                <div class="info-val" id="matchEta" style="font-size:0.8rem; color:#555; margin-top:2px;">Mesafe hesaplanıyor...</div>
                <button type="button" id="passengerMatchSOS" class="sos-btn" onclick="sendSOS('passenger')">🆘 ACİL DURUM / SOS</button>
                <div id="passengerChatBox" class="chat-box hidden">
                    <div class="chat-head"><span>Sürücü ile Canlı Sohbet</span><span class="chat-live">● CANLI</span></div>
                    <div id="passengerChatMessages" class="chat-messages" aria-live="polite"></div>
                    <div class="chat-quick">
                        <button type="button" onclick="sendQuickChat('passenger','Neredesiniz?')">Neredesiniz?</button>
                        <button type="button" onclick="sendQuickChat('passenger','Kaç dakikaya gelirsiniz?')">Kaç dakikaya gelirsiniz?</button>
                        <button type="button" onclick="sendQuickChat('passenger','Beni arayabilir misiniz?')">Beni arayabilir misiniz?</button>
                        <button type="button" onclick="sendQuickChat('passenger','Konumumu paylaştım.')">Konumumu paylaştım</button>
                    </div>
                    <div class="chat-compose"><input id="passengerChatInput" class="input-box" maxlength="500" placeholder="Mesajınızı yazın..." onkeydown="if(event.key==='Enter')sendChatMessage('passenger')"><button type="button" onclick="sendChatMessage('passenger')">Gönder</button></div>
                </div>
                <div class="code-label">Doğrulama Kodunuz</div>
                <div class="code-big" id="matchCode">----</div>
                <div class="info-val" id="matchHint" style="font-size:0.72rem; color:#555; margin-top:4px;">Sürücü geldiğinde bu kodu söyleyin.</div>
            </div>

            <!-- KOD DOĞRU GİRİLDİĞİNDE GÖZÜKECEK YOLCULUK BAŞLADI KARTI -->
            <div id="passengerInRideCard" class="hidden info-card" style="border:2px solid #0288d1; background:#e1f5fe; padding:15px; text-align:center;">
                <div style="font-size:1.3rem; font-weight:900; color:#0288d1; margin-bottom:6px;">YOLCULUK BAŞLADI</div>
                <div class="info-val" id="inRideDriverName" style="font-size:1rem;">Sürücü: --</div>
                <div class="info-val" id="inRideStats" style="font-size:0.85rem; color:#555; margin-top:4px;">Varışa Kalan: Hesaplanıyor...</div>
                <div class="info-val" id="inRideFare" style="font-size:1.2rem; color:#008736; margin-top:6px; font-weight:800;">Toplam Tutar: 0 TL</div>
                <button type="button" id="passengerInRideSOS" class="sos-btn" onclick="sendSOS('passenger')">🆘 ACİL DURUM / SOS</button>
            </div>

            <div class="info-card" id="rideDetailsCard">
                <div class="info-title">Yolculuk Detayları & Ücret</div>
                <div class="info-val" id="fareDisplay">Ücret: 150.00 TL (Minimum ücret)</div>
                <div class="info-val" id="tripInfoDisplay" style="font-size:0.75rem; color:#555; margin-top:3px;">Mesafe ve Süre bekleniyor...</div>
            </div>

            <button class="action-btn" id="reqBtn" onclick="sendRideRequest()">LION ÇAĞIR</button>
            <button class="action-btn danger-btn hidden" id="cancelReqBtn" onclick="cancelRide()">İptal Et</button>
        </div>

        <!-- Sürücü Paneli -->
        <div id="driverPanel" class="hidden">
            <div id="driverLoginBox">
                <div class="status-badge" style="background:rgba(41,182,246,0.2); color:#0288d1;">SÜRÜCÜ GİRİŞİ</div>
                <div class="info-card" style="border: 1px solid #29b6f6;">
                    <div class="info-title">Telefon Numarası</div>
                    <input type="tel" id="driverPhoneInput" class="input-box" placeholder="Örn: 05321234567">

                    <div class="info-title" style="margin-top:6px;">Özel Kod (Şifre)</div>
                    <input type="password" id="driverCodeInput" class="input-box" placeholder="Örn: 1234">

                    <button class="action-btn driver-btn" onclick="loginDriver()">GİRİŞ YAP</button>
                </div>
            </div>

            <div id="driverActiveBox" class="hidden">
                <div class="status-badge st-matched" id="driverWelcomeBadge">SÜRÜCÜ ÇEVRİMİÇİ</div>
                
                <!-- Çevrimiçi / Çevrimdışı Butonu -->
                <div class="toggle-container">
                    <span style="font-size:0.8rem; font-weight:700;" id="toggleStatusText">Durum: ÇEVRİMİÇİ</span>
                    <label class="toggle-switch">
                        <input type="checkbox" id="driverOnlineToggle" checked onchange="toggleDriverStatus(this.checked)">
                        <span class="slider"></span>
                    </label>
                </div>

                <div class="info-card">
                    <div class="info-title">Durum & Konum</div>
                    <div class="info-val" id="driverStatusText" style="font-size:0.8rem;">GPS konumu otomatik güncelleniyor. Yolcu bekleniyor...</div>
                </div>

                <div id="driverOfferBox"></div>
                <button type="button" id="driverSOSBtn" class="sos-btn hidden" onclick="sendSOS('driver')">🆘 ACİL DURUM / SOS</button>
                <div id="driverChatBox" class="chat-box driver-chat hidden">
                    <div class="chat-head"><span>Yolcu ile Canlı Sohbet</span><span class="chat-live">● CANLI</span></div>
                    <div id="driverChatMessages" class="chat-messages" aria-live="polite"></div>
                    <div class="chat-quick">
                        <button type="button" onclick="sendQuickChat('driver','Yoldayım.')">Yoldayım</button>
                        <button type="button" onclick="sendQuickChat('driver','5 dakikaya oradayım.')">5 dakikaya oradayım</button>
                        <button type="button" onclick="sendQuickChat('driver','Trafik var, biraz gecikeceğim.')">Trafik var</button>
                        <button type="button" onclick="sendQuickChat('driver','Konumunuza yaklaştım.')">Yaklaştım</button>
                        <button type="button" onclick="sendQuickChat('driver','Geldim, sizi bekliyorum.')">Geldim, bekliyorum</button>
                    </div>
                    <div class="chat-compose"><input id="driverChatInput" class="input-box" maxlength="500" placeholder="Mesajınızı yazın..." onkeydown="if(event.key==='Enter')sendChatMessage('driver')"><button type="button" onclick="sendChatMessage('driver')">Gönder</button></div>
                </div>

                <div id="driverNavigationBox" class="hidden" style="margin-top:8px;">
                    <a id="googleMapsNavBtn" href="#" target="_blank" class="action-btn maps-btn">Google Maps ile Yola Çık</a>
                </div>

                <button id="arrivalBtn" class="action-btn driver-btn hidden" onclick="notifyArrival()">KONUMA VARDIM</button>

                <div id="codeVerifyBox" class="hidden">
                    <div class="info-card" style="border: 1px solid #00e676;">
                        <div class="info-title" style="color:#008736">YOLCULUĞU BAŞLAT</div>
                        <div class="info-val" style="font-size:0.75rem; margin-bottom:4px;">Yolcuya varış bildirildi. Yolcudaki 4 haneli kodu girin:</div>
                        <input type="text" id="codeVerifyInput" class="input-box" placeholder="Örn: 4829" maxlength="4" inputmode="numeric">
                        <button class="action-btn driver-btn" style="margin-top:6px;" onclick="verifyRideCode()">KODU ONAYLA VE BAŞLAT</button>
                    </div>
                </div>

                <button id="driverCancelOrFinishBtn" class="action-btn danger-btn hidden" onclick="driverCancelOrFinish()" style="margin-top:8px;">İptal Et</button>
                <button class="action-btn logout-btn" onclick="logoutDriver()">HESAPTAN ÇIKIŞ YAP</button>
            </div>
        </div>

        <button class="reset-btn" id="reloadBtn" onclick="location.reload()">Sayfayı Yenile / Sıfırla</button>
    </div>
</div>

<!-- DEĞERLENDİRME POPUP -->
<div id="ratingModal" class="rating-modal-backdrop hidden">
    <div class="rating-card">
        <h3 style="font-size:1.2rem; font-weight:800; color:#111;">Yolculuk Tamamlandı!</h3>
        <p style="font-size:0.8rem; color:#666; margin-top:4px;" id="ratingModalDriverName">Sürücünüzü Değerlendirin</p>

        <div class="star-rating" id="starContainer">
            <span class="star active" onclick="setRating(1)">★</span>
            <span class="star active" onclick="setRating(2)">★</span>
            <span class="star active" onclick="setRating(3)">★</span>
            <span class="star active" onclick="setRating(4)">★</span>
            <span class="star active" onclick="setRating(5)">★</span>
        </div>

        <input type="text" id="ratingComment" class="input-box" placeholder="Sürücü ve sürüş hakkında yorumunuz..." style="margin-bottom:12px;" maxlength="200">
        <button class="action-btn" onclick="submitRating()" style="margin-top:0;">DEĞERLENDİRMEYİ GÖNDER</button>
    </div>
</div>
<div id="passengerRatingModal" class="rating-modal-backdrop hidden">
    <div class="rating-card">
        <h3 style="font-size:1.2rem;font-weight:800;color:#111">Yolcu Değerlendirmesi</h3>
        <p id="passengerRatingTarget" style="font-size:.8rem;color:#666;margin-top:4px">Yolcuyu değerlendirin</p>
        <div class="star-rating" id="passengerStarContainer">
            <span class="star active" onclick="setPassengerRating(1)">★</span><span class="star active" onclick="setPassengerRating(2)">★</span><span class="star active" onclick="setPassengerRating(3)">★</span><span class="star active" onclick="setPassengerRating(4)">★</span><span class="star active" onclick="setPassengerRating(5)">★</span>
        </div>
        <input id="passengerRatingComment" class="input-box" placeholder="Yolcu hakkındaki yorumunuz..." maxlength="200" style="margin-bottom:12px">
        <button class="action-btn driver-btn" onclick="submitPassengerRating()" style="margin-top:0">YOLCUYU DEĞERLENDİR</button>
    </div>
</div>


<div id="announcementPopup" class="announcement-overlay hidden" role="dialog" aria-modal="true" aria-labelledby="announcementPopupTitle">
  <div class="announcement-card">
    <div style="font-size:.72rem;font-weight:900;color:#b77900;letter-spacing:.08em;margin-bottom:8px">📢 LION CITY DUYURUSU</div>
    <h3 id="announcementPopupTitle"></h3><p id="announcementPopupBody"></p>
    <div class="announcement-actions"><button class="announcement-primary" onclick="closeAnnouncementPopup()">Anladım</button></div>
  </div>
</div>
<div id="announcementListOverlay" class="announcement-overlay hidden" role="dialog" aria-modal="true" aria-labelledby="announcementListTitle" onclick="if(event.target===this)closeAnnouncements()">
  <div class="announcement-card">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:12px"><h3 id="announcementListTitle">📢 Duyurular</h3><button class="announcement-secondary" onclick="closeAnnouncements()">✕</button></div>
    <div id="announcementListContent">Duyurular yükleniyor...</div>
  </div>
</div>
<script>
    let map = L.map('map' , { zoomControl: false }).setView([41.0082, 28.9784], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19, attribution: '&copy; OpenStreetMap'
    }).addTo(map);

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);

    let currentMode = 'passenger';
    let userLocation = null;
    let markers = {};
    let radarMarkers = {};
    let routePolyline = null;
    let driverRoutePolyline = null;
    let pickupCoords = null;
    let pickupIsGps = true;
    let dropoffCoords = null;
    let driverCoords = null;
    let offerTimer = null;
    let calculatedFare = 150;
    let calculatedDistanceKm = null;
    let rideRequested = false;
    let rideStarted = false;
    let isDriverLoggedIn = false;
    let assignedPickup = null;
    let assignedDropoff = null;
    let currentDriverName = "";
    let currentDriverPhone = "";
    let completedRideId = "";
    let ratingSubmitted = false;
    let ratingSubmitting = false;
    let selectedRating = 5;
    let lastGpsSentAt = 0;
    let lastRouteFetchAt = 0;
    let gpsWatchId = null;
    let gpsSendTimer = null;
    let driverCentered = false;
    let passengerRatingValue = 5;
    let passengerRatingRideId = "";
    let passengerRatingSubmitting = false;
    let completedPassengerId = "";
    let passengerProfile = {};
    let passengerSessionToken = localStorage.getItem('lion_passenger_session') || '';
    let passengerAuthMode = 'register';
    let passengerAuthenticated = false;
    let activeRideId = "";
    let chatReady = false;

    function esc(s) {
        return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    }
    function el(id) { return document.getElementById(id); }
    function send(obj) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj)); }

    function renderChatMessage(message) {
        const targetId = isDriverLoggedIn ? 'driverChatMessages' : 'passengerChatMessages';
        const target = el(targetId);
        if (!target) return;
        const mine = (message.senderRole === (isDriverLoggedIn ? 'driver' : 'passenger'));
        const item = document.createElement('div');
        item.className = 'chat-message' + (mine ? ' mine' : '');
        const body = document.createElement('span');
        body.textContent = message.text || '';
        const stamp = document.createElement('span');
        stamp.className = 'chat-time';
        stamp.textContent = new Date((message.createdAt || Date.now()) * (message.createdAt ? 1000 : 1)).toLocaleTimeString('tr-TR', {hour:'2-digit',minute:'2-digit'});
        item.append(body, stamp);
        target.appendChild(item);
        target.scrollTop = target.scrollHeight;
    }
    function showChat(visible) {
        chatReady = !!visible;
        el('passengerChatBox').classList.toggle('hidden', !visible || isDriverLoggedIn);
        el('driverChatBox').classList.toggle('hidden', !visible || !isDriverLoggedIn);
    }
    let sosSending = false;
    let sosSendTimeout = null;
    function sendSOS(role) {
        role = role === 'driver' ? 'driver' : 'passenger';
        if (sosSending) return;
        if (!activeRideId) {
            alert("SOS yalnızca sürücüyle eşleştikten sonra, aktif yolculukta kullanılabilir.");
            return;
        }
        if (!ws || ws.readyState !== WebSocket.OPEN) {
            alert("Sunucu bağlantısı yok. İnternet bağlantınızı kontrol edip tekrar deneyin.");
            return;
        }
        if (!window.confirm("ACİL DURUM BİLDİRİMİ GÖNDERİLSİN Mİ?\\n\\nYöneticiye ve yolculuğun diğer tarafına konumunuzla birlikte SOS uyarısı gönderilecektir. Gerçek acil durumda 112'yi de arayın.")) return;

        const buttonIds = role === 'driver'
            ? ['driverSOSBtn']
            : ['passengerMatchSOS', 'passengerInRideSOS'];
        const buttons = buttonIds.map(id => el(id)).filter(Boolean);
        sosSending = true;
        buttons.forEach(btn => {
            btn.disabled = true;
            btn.dataset.oldText = btn.textContent;
            btn.textContent = '⏳ SOS GÖNDERİLİYOR...';
        });

        const coords = userLocation || (role === 'driver' ? driverCoords : pickupCoords);
        const payload = {type:'SOS_ALERT', role:role, rideId:activeRideId, message:'Acil yardım gerekiyor.'};
        if (Array.isArray(coords) && coords.length === 2 &&
            Number.isFinite(Number(coords[0])) && Number.isFinite(Number(coords[1]))) {
            payload.lat = Number(coords[0]);
            payload.lng = Number(coords[1]);
        }
        send(payload);
        if (sosSendTimeout) clearTimeout(sosSendTimeout);
        sosSendTimeout = setTimeout(() => {
            if (!sosSending) return;
            finishSOSRequest(false, "Sunucudan yanıt alınamadı. Bağlantıyı kontrol edin.");
        }, 12000);
    }

    function finishSOSRequest(success, message) {
        sosSending = false;
        if (sosSendTimeout) { clearTimeout(sosSendTimeout); sosSendTimeout = null; }
        document.querySelectorAll('.sos-btn').forEach(btn => {
            btn.disabled = false;
            btn.textContent = btn.dataset.oldText || '🆘 ACİL DURUM / SOS';
        });
        if (success) {
            playBeep(880, 'sawtooth', 500);
            alert("🆘 " + (message || "Acil durum bildiriminiz yöneticiye iletildi.") + " Gerçek acil durumda 112'yi de arayın.");
        } else if (message) {
            alert("SOS gönderilemedi: " + message + " Gerekiyorsa 112'yi arayın.");
        }
    }

    function sendChatMessage(role) {
        if (!chatReady || !activeRideId) return;
        const input = el(role === 'driver' ? 'driverChatInput' : 'passengerChatInput');
        const message = input.value.trim();
        if (!message) return;
        send({type:'CHAT_SEND', rideId:activeRideId, text:message});
        input.value = '';
    }
    function sendQuickChat(role, message) {
        if (!chatReady || !activeRideId) return;
        send({type:'CHAT_SEND', rideId:activeRideId, text:message});
    }

    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    function playBeep(freq = 440, type = 'sine', duration = 200) {
        try {
            if (audioCtx.state === 'suspended') { audioCtx.resume(); }
            let osc = audioCtx.createOscillator();
            let gain = audioCtx.createGain();
            osc.type = type;
            osc.frequency.value = freq;
            gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.start();
            setTimeout(() => { osc.stop(); }, duration);
        } catch (e) {}
    }

    ws.onopen = () => {
        startGPS();
        autoLoginDriver();
        setMode('passenger');
        if (passengerSessionToken) send({type:"PASSENGER_TOKEN_LOGIN", token:passengerSessionToken});
        updatePassengerAuthUI();
        setTimeout(() => { map.invalidateSize(); }, 300);
    };

    ws.onclose = () => {
        el('pStatus').innerText = "Bağlantı koptu - sayfayı yenileyin";
    };

    ws.onmessage = (e) => {
        const data = JSON.parse(e.data);
        if (data.type === "STATS_UPDATE") {
            el('statPassengers').innerText = data.passengers;
            el('statDrivers').innerText = data.drivers;
            updateRadarDrivers(data.driversList || []);
        } else if (data.type === "PASSENGER_AUTH_SUCCESS") {
            passengerAuthenticated=true;passengerSessionToken=data.token;passengerProfile=data.profile||{};localStorage.setItem('lion_passenger_session',passengerSessionToken);el('passengerAuthMessage').innerText='';updatePassengerAuthUI();send({type:'GET_PROFILE',role:'passenger'});el('pStatus').innerText='Yolcu hesabı hazır';
        } else if (data.type === "PASSENGER_AUTH_ERROR") {
            el('passengerAuthMessage').innerText=data.message||'Giriş işlemi başarısız.';
        } else if (data.type === "PASSENGER_LOGOUT_SUCCESS") {
            passengerAuthenticated=false;passengerProfile={};updatePassengerAuthUI();
        } else if (data.type === "LOGIN_SUCCESS") {
            isDriverLoggedIn = true;
            setMode('driver');
            if (data.phone && data.code) {
                localStorage.setItem("lion_driver_phone", data.phone);
                localStorage.setItem("lion_driver_code", data.code);
            }
            el('driverLoginBox').classList.add('hidden');
            el('driverActiveBox').classList.remove('hidden');
            el('driverWelcomeBadge').innerText = `SÜRÜCÜ: ${data.name.toUpperCase()}`;
            el('driverProfileName').innerText = data.name;
            el('driverProfilePhone').innerText = data.phone || '';
            updatePassengerAuthUI();
            send({type:"GET_PROFILE", role:"driver"});
            const avg = Number(data.ratingAverage || 0);
            el('driverRatingValue').innerText = avg ? `★ ${avg.toFixed(2)} / 5` : '★ -- / 5';
            el('driverRatingCount').innerText = `${data.ratingCount || 0} değerlendirme`;
            playBeep(800, 'sine', 300);
            startGPS();
        } else if (data.type === "LOGIN_FAILED") {
            localStorage.removeItem("lion_driver_phone");
            localStorage.removeItem("lion_driver_code");
            alert(data.message);
        } else {
            handleServerEvent(data);
        }
    };

    function applyDarkMode(enabled) {
        document.body.classList.toggle('dark-mode', !!enabled);
        localStorage.setItem('lion_dark_mode', enabled ? '1' : '0');
        const button = el('themeToggleBtn');
        if (button) button.innerText = enabled ? '☀️ Açık modu kullan' : '🌙 Koyu modu aç';
        setTimeout(() => { if (map) map.invalidateSize(); }, 80);
    }
    function toggleDarkMode() { applyDarkMode(!document.body.classList.contains('dark-mode')); }
    applyDarkMode(localStorage.getItem('lion_dark_mode') === '1');

    function toggleProfileMenu(force) {
        const drawer=el('profileDrawer'); const open=typeof force==='boolean'?force:!drawer.classList.contains('open');
        drawer.classList.toggle('open',open); el('profileBackdrop').classList.toggle('hidden',!open); drawer.setAttribute('aria-hidden',open?'false':'true');
        if(open){updatePassengerAuthUI();if(isDriverLoggedIn)send({type:'GET_PROFILE',role:'driver'});else if(passengerAuthenticated)send({type:'GET_PROFILE',role:'passenger'});}
    }
    function switchPassengerAuthMode(){passengerAuthMode=passengerAuthMode==='register'?'login':'register';updatePassengerAuthUI();}
    function updatePassengerAuthUI(){
        el('passengerAuthBox').classList.toggle('hidden',passengerAuthenticated || isDriverLoggedIn);el('passengerProfileCard').classList.toggle('hidden',!passengerAuthenticated || isDriverLoggedIn);el('driverProfileCard').classList.toggle('hidden',!isDriverLoggedIn);
        el('passengerRegisterFields').classList.toggle('hidden',passengerAuthMode!=='register');el('passengerAuthSubmit').innerText=passengerAuthMode==='register'?'KAYIT OL':'GİRİŞ YAP';
        el('passengerAuthSwitch').innerText=passengerAuthMode==='register'?'Zaten hesabım var · Giriş yap':'İlk kez kullanıyorum · Kayıt ol';
        el('passengerAuthModeLabel').innerText=passengerAuthMode==='register'?'Telefon numarasıyla yalnızca bir kez kayıt olun.':'Kayıtlı telefon numaranız ve şifrenizle giriş yapın.';
        if(passengerAuthenticated){el('passengerProfileName').innerText=`${passengerProfile.firstName||''} ${passengerProfile.lastName||''}`.trim();el('passengerProfilePhone').innerText=passengerProfile.phone||'';el('profileDrawerSubtitle').innerText=el('passengerProfileName').innerText;}else if(isDriverLoggedIn){el('profileDrawerSubtitle').innerText='Sürücü profili';}else{el('profileDrawerSubtitle').innerText='Yolcu hesabı';}
    }
    function submitPassengerAuth(){
        const phone=el('passengerAuthPhone').value.trim(),password=el('passengerAuthPassword').value;
        if(!phone||!password){el('passengerAuthMessage').innerText='Telefon ve şifre zorunludur.';return;}
        if(passengerAuthMode==='register'){const firstName=el('passengerFirstName').value.trim(),lastName=el('passengerLastName').value.trim();if(!firstName||!lastName){el('passengerAuthMessage').innerText='Ad ve soyad alanlarını doldurun.';return;}if(password.length<8){el('passengerAuthMessage').innerText='Şifre en az 8 karakter olmalıdır.';return;}send({type:'PASSENGER_REGISTER',phone,password,firstName,lastName});}
        else send({type:'PASSENGER_LOGIN',phone,password});
    }
    function logoutPassenger(){passengerAuthenticated=false;passengerProfile={};passengerSessionToken='';localStorage.removeItem('lion_passenger_session');el('passengerHistory').innerHTML='';send({type:'PASSENGER_LOGOUT'});updatePassengerAuthUI();toggleProfileMenu(false);alert('Yolcu hesabından çıkış yapıldı.');}
    function renderHistory(targetId, items, role) {
        const target = el(targetId);
        if (!items || !items.length) { target.innerHTML = '<span style="color:#777">Henüz tamamlanmış yolculuk yok.</span>'; return; }
        target.innerHTML = items.slice(0,30).map(item => {
            const when = item.completedAt ? new Date(item.completedAt * 1000).toLocaleString('tr-TR') : 'Tarih bilgisi yok';
            const other = role === 'driver' ? `Yolcu: ${esc(item.passengerName || 'Yolcu')}` : `Sürücü: ${esc(item.driverName || 'Sürücü')}`;
            const ownRating = role === 'driver' ? item.passengerRating : item.driverRating;
            const received = role === 'driver' ? item.driverRating : item.passengerRating;
            const action = !ownRating ? (role === 'driver'
                ? `<button class="action-btn driver-btn" data-rate-passenger data-ride="${esc(item.rideId || '')}" data-passenger="${esc(item.passengerId || '')}" style="padding:7px;margin-top:5px">Yolcuyu değerlendir</button>`
                : `<button class="action-btn" data-rate-driver data-ride="${esc(item.rideId || '')}" data-phone="${esc(item.driverPhone || '')}" style="padding:7px;margin-top:5px">Sürücüyü değerlendir</button>`) : '';
            return `<div style="border-top:1px solid #ddd;padding:6px 0"><b>${other}</b><br>${when} · ${Number(item.fare || 0).toFixed(0)} TL<br>Verdiğiniz puan: ${ownRating ? '★ '+ownRating+'/5' : 'Henüz yok'} · Aldığınız puan: ${received ? '★ '+received+'/5' : 'Henüz yok'}${(role === 'driver' ? item.passengerComment : item.driverComment) ? `<br><span>Verdiğiniz yorum: ${esc(role === 'driver' ? item.passengerComment : item.driverComment)}</span>` : ''}${(role === 'driver' ? item.driverComment : item.passengerComment) ? `<br><span>Aldığınız yorum: ${esc(role === 'driver' ? item.driverComment : item.passengerComment)}</span>` : ''}${action}</div>`;
        }).join('');
        target.querySelectorAll('[data-rate-driver]').forEach(btn => btn.addEventListener('click', () => rateHistoryDriver(btn.dataset.ride, btn.dataset.phone)));
        target.querySelectorAll('[data-rate-passenger]').forEach(btn => btn.addEventListener('click', () => rateHistoryPassenger(btn.dataset.ride, btn.dataset.passenger)));
    }
    function rateHistoryDriver(rideId, phone) {
        completedRideId = rideId; currentDriverPhone = phone; ratingSubmitted = false; ratingSubmitting = false;
        el('ratingModalDriverName').innerText = 'Bu yolculuktaki sürücüyü değerlendirin.';
        setRating(5); el('ratingModal').classList.remove('hidden');
    }
    function rateHistoryPassenger(rideId, passengerId) {
        passengerRatingRideId = rideId; completedPassengerId = passengerId; passengerRatingSubmitting = false;
        el('passengerRatingTarget').innerText = 'Bu yolculuktaki yolcuyu değerlendirin.';
        setPassengerRating(5); el('passengerRatingModal').classList.remove('hidden');
    }
    function autoLoginDriver() {
        const savedPhone = localStorage.getItem("lion_driver_phone");
        const savedCode = localStorage.getItem("lion_driver_code");
        if (savedPhone && savedCode) {
            setMode('driver');
            send({ type: "DRIVER_LOGIN", phone: savedPhone, code: savedCode });
        }
    }

    function loginDriver() {
        const phone = el('driverPhoneInput').value.trim();
        const code = el('driverCodeInput').value.trim();
        if (!phone || !code) {
            alert("Lütfen telefon numaranızı ve özel kodu girin!");
            return;
        }
        send({ type: "DRIVER_LOGIN", phone: phone, code: code });
    }

    function logoutDriver() {
        send({ type: "DRIVER_LOGOUT" });
        localStorage.removeItem("lion_driver_phone");
        localStorage.removeItem("lion_driver_code");
        isDriverLoggedIn = false;
        resetDriverUI();
        if (markers.selfDriver) { map.removeLayer(markers.selfDriver); delete markers.selfDriver; }
        el('driverActiveBox').classList.add('hidden');
        el('driverLoginBox').classList.remove('hidden');
        updatePassengerAuthUI();
        el('driverPhoneInput').value = "";
        el('driverCodeInput').value = "";
    }

    function toggleDriverStatus(isOnline) {
        const status = isOnline ? "AVAILABLE" : "OFFLINE";
        send({ type: "SET_DRIVER_STATUS", status: status });
        el('toggleStatusText').innerText = isOnline ? "Durum: ÇEVRİMİÇİ" : "Durum: ÇEVRİMDİŞI";
        el('driverWelcomeBadge').innerText = isOnline ? "SÜRÜCÜ ÇEVRİMİÇİ" : "SÜRÜCÜ ÇEVRİMDİŞI";
        el('driverWelcomeBadge').className = isOnline ? "status-badge st-matched" : "status-badge st-offline";
    }

    function startGPS() {
        if (gpsWatchId !== null) return;
        if ("geolocation" in navigator) {
            gpsWatchId = navigator.geolocation.watchPosition((pos) => {
                userLocation = [pos.coords.latitude, pos.coords.longitude];

                if (isDriverLoggedIn) {
                    driverCoords = userLocation;
                    updateDriverMarker(driverCoords);
                    if (currentMode === 'driver' && assignedPickup && !rideStarted) drawDriverRoute(driverCoords, assignedPickup);
                    else if (currentMode === 'driver' && assignedDropoff && rideStarted) drawDriverRoute(driverCoords, assignedDropoff);
                    if (currentMode === 'driver' && !driverCentered) {
                        map.setView(driverCoords, 15);
                        driverCentered = true;
                    }
                } else if (currentMode === 'passenger') {
                    if (pickupIsGps && !rideRequested) {
                        const firstGpsFix = !pickupCoords;
                        pickupCoords = userLocation;
                        if (firstGpsFix) map.setView(userLocation, 14);
                        updatePickupMarker(userLocation, "Canlı Konumum (GPS)");
                        el('pickupInput').value = "Mevcut Konumum (GPS)";
                    }
                }
            }, (err) => {
                if (!userLocation) { userLocation = [41.0082, 28.9784]; }
            }, { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 });
            if (gpsSendTimer === null) {
                gpsSendTimer = setInterval(() => {
                    if (!userLocation || ws.readyState !== WebSocket.OPEN) return;
                    const packetType = isDriverLoggedIn ? "GPS_UPDATE" : "PASSENGER_LOCATION_UPDATE";
                    send({ type: packetType, lat: userLocation[0], lng: userLocation[1] });
                }, 1000);
            }
        }
    }

    function updatePickupMarker(coords, title) {
        if (markers.pickup) map.removeLayer(markers.pickup);
        markers.pickup = L.marker(coords, {
            icon: L.divIcon({ className: 'pickup-marker', iconSize: [14, 14], iconAnchor: [7, 7] })
        }).addTo(map).bindPopup(esc(title));
    }

    function updateDropoffMarker(coords, title) {
        if (markers.dropoff) map.removeLayer(markers.dropoff);
        markers.dropoff = L.marker(coords, {
            icon: L.divIcon({ className: 'dropoff-marker', iconSize: [14, 14], iconAnchor: [7, 7] })
        }).addTo(map).bindPopup(esc(title));
    }

    function updateDriverMarker(coords) {
        if (markers.selfDriver) {
            markers.selfDriver.setLatLng(coords);
        } else {
            markers.selfDriver = L.marker(coords, {
                icon: L.divIcon({ className: 'driver-marker', iconSize: [16, 16], iconAnchor: [8, 8] })
            }).addTo(map).bindPopup("Sizin Konumunuz");
        }
    }

    function updateRadarDrivers(driversList) {
        let currentIds = new Set();
        driversList.forEach(d => {
            if (d.lat !== null && d.lng !== null && d.id) {
                currentIds.add(d.id);
                if (radarMarkers[d.id]) {
                    radarMarkers[d.id].setLatLng([d.lat, d.lng]);
                } else {
                    radarMarkers[d.id] = L.marker([d.lat, d.lng], {
                        icon: L.divIcon({ className: 'radar-driver-marker', iconSize: [12, 12], iconAnchor: [6, 6] })
                    }).addTo(map).bindPopup(`Aktif Sürücü: ${esc(d.name)}`);
                }
            }
        });
        for (let id in radarMarkers) {
            if (!currentIds.has(id)) {
                map.removeLayer(radarMarkers[id]);
                delete radarMarkers[id];
            }
        }
    }

    function setMode(mode) {
        currentMode = mode;
        el('pModeBtn').className = mode === 'passenger' ? 'mode-btn active-p' : 'mode-btn';
        el('dModeBtn').className = mode === 'driver' ? 'mode-btn active-d' : 'mode-btn';

        if (mode === 'passenger') {
            el('passengerPanel').classList.remove('hidden');
            el('driverPanel').classList.add('hidden');
            if (pickupCoords) map.setView(pickupCoords, 14);
            send({ type: "REGISTER_ROLE", role: "passenger" });
            if (passengerAuthenticated) send({type:"GET_PROFILE", role:"passenger"});
        } else {
            el('passengerPanel').classList.add('hidden');
            el('driverPanel').classList.remove('hidden');

            if (!isDriverLoggedIn) {
                el('driverLoginBox').classList.remove('hidden');
                el('driverActiveBox').classList.add('hidden');
            } else {
                el('driverLoginBox').classList.add('hidden');
                el('driverActiveBox').classList.remove('hidden');
                if (driverCoords) map.setView(driverCoords, 15);
            }
        }
        setTimeout(() => { map.invalidateSize(); }, 200);
    }

    map.on('click', (e) => {
        if (currentMode === 'passenger' && !rideRequested) {
            dropoffCoords = [e.latlng.lat, e.latlng.lng];
            updateDropoffMarker(dropoffCoords, "Varış Noktası");
            el('dropoffInput').value = `${e.latlng.lat.toFixed(4)}, ${e.latlng.lng.toFixed(4)}`;
            calculatedDistanceKm = null;
            if (pickupCoords) drawRoute(pickupCoords, dropoffCoords);
        }
    });

    async function searchAddress(query, type) {
        if (!query || rideRequested) return;
        try {
            const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`);
            const data = await res.json();
            if (data && data.length > 0) {
                const coords = [parseFloat(data[0].lat), parseFloat(data[0].lon)];
                if (type === 'pickup') {
                    pickupCoords = coords;
                    pickupIsGps = false;
                    updatePickupMarker(coords, data[0].display_name);
                } else {
                    dropoffCoords = coords;
                    updateDropoffMarker(coords, data[0].display_name);
                }
                map.setView(coords, 14);
                calculatedDistanceKm = null;
                if (pickupCoords && dropoffCoords) drawRoute(pickupCoords, dropoffCoords);
            } else {
                alert("Adres bulunamadı.");
            }
        } catch (e) {}
    }

    async function sendRideRequest() {
        if (!passengerAuthenticated || !passengerProfile.id) { alert('Yolculuk çağırmak için önce üç çizgili menüden yolcu hesabınıza kayıt olun veya giriş yapın.'); toggleProfileMenu(true); return; }
        if (!pickupCoords || !dropoffCoords) {
            alert("Lütfen kalkış ve varış noktalarını belirleyin!");
            return;
        }
        if (rideRequested) return;
        if (calculatedDistanceKm === null) {
            await drawRoute(pickupCoords, dropoffCoords);
        }
        if (calculatedDistanceKm === null) {
            alert("Rota ve mesafe hesaplanamadı. Lütfen internet bağlantınızı kontrol edip tekrar deneyin.");
            return;
        }
        calculatedFare = Math.max(150, Math.round(calculatedDistanceKm * 30));

        rideRequested = true;
        el('reqBtn').classList.add('hidden');
        el('cancelReqBtn').classList.remove('hidden');
        el('pickupInput').disabled = true;
        el('dropoffInput').disabled = true;
        el('pStatus').innerText = "Sürücü aranıyor...";
        el('pStatus').className = "status-badge st-waiting";

        assignedPickup = pickupCoords;
        assignedDropoff = dropoffCoords;

        playBeep(600, 'sine', 150);
        send({ type: "RIDE_REQUEST", pickup: pickupCoords, dropoff: dropoffCoords, fare: calculatedFare });
    }

    function cancelRide() {
        send({ type: "CANCEL_RIDE" });
    }

    let finishingRide = false;

    function driverCancelOrFinish() {
        if (rideStarted) {
            if (finishingRide) return;
            if (!confirm("Yolculuğu tamamlamak istediğinize emin misiniz?")) return;
            finishingRide = true;
            const btn = el('driverCancelOrFinishBtn');
            btn.disabled = true;
            btn.innerText = "Yolculuk Bitiriliyor...";
            send({ type: "FINISH_RIDE" });
        } else {
            cancelRide();
        }
    }

    function notifyArrival() {
        el('arrivalBtn').disabled = true;
        send({ type: "DRIVER_ARRIVED" });
    }

    function setRating(rating) {
        selectedRating = rating;
        document.querySelectorAll('#starContainer .star').forEach((s, idx) => {
            s.classList.toggle('active', idx < rating);
        });
    }

    function submitRating() {
        if (ratingSubmitted || ratingSubmitting || !completedRideId || !currentDriverPhone) {
            alert("Bu yolculuk için değerlendirme bilgisi bulunamadı.");
            return;
        }
        ratingSubmitting = true;
        send({
            type: "RATE_DRIVER",
            rating: selectedRating,
            comment: el('ratingComment').value.trim(),
            driverPhone: currentDriverPhone,
            rideId: completedRideId
        });
    }

    function setPassengerRating(rating) {
        passengerRatingValue = rating;
        document.querySelectorAll('#passengerStarContainer .star').forEach((star, idx) => star.classList.toggle('active', idx < rating));
    }
    function submitPassengerRating() {
        if (passengerRatingSubmitting || !passengerRatingRideId || !completedPassengerId) { alert('Bu yolculuk için değerlendirme bilgisi bulunamadı.'); return; }
        passengerRatingSubmitting = true;
        send({type:'RATE_PASSENGER', rating:passengerRatingValue, comment:el('passengerRatingComment').value.trim(), rideId:passengerRatingRideId, passengerId:completedPassengerId});
    }

    function clearRoutes() {
        if (routePolyline) { map.removeLayer(routePolyline); routePolyline = null; }
        if (driverRoutePolyline) { map.removeLayer(driverRoutePolyline); driverRoutePolyline = null; }
    }

    function resetPassengerUI() {
        if (offerTimer) clearInterval(offerTimer);
        rideRequested = false;
        rideStarted = false;
        activeRideId = "";
        showChat(false);
        el('passengerChatMessages').innerHTML = '';
        assignedPickup = null;
        assignedDropoff = null;
        dropoffCoords = null;
        calculatedFare = 150;
        calculatedDistanceKm = null;

        clearRoutes();
        if (markers.dropoff) { map.removeLayer(markers.dropoff); delete markers.dropoff; }
        if (markers.driver) { map.removeLayer(markers.driver); delete markers.driver; }

        el('pStatus').innerText = "Konum Hazır";
        el('pStatus').className = "status-badge st-waiting";
        el('passengerActiveRideBox').classList.remove('hidden');
        el('rideDetailsCard').classList.remove('hidden');
        el('passengerMatchCard').classList.add('hidden');
        el('passengerMatchCard').classList.remove('arrived');
        el('matchCode').innerText = "----";
        el('passengerInRideCard').classList.add('hidden');
        el('passengerMatchSOS').classList.remove('hidden');
        el('passengerInRideSOS').classList.remove('hidden');
        el('pickupInput').disabled = false;
        el('dropoffInput').disabled = false;
        el('dropoffInput').value = "";
        el('fareDisplay').innerText = "Ücret: 150.00 TL (Minimum ücret)";
        el('tripInfoDisplay').innerText = "Mesafe ve Süre bekleniyor...";
        el('inRideStats').innerText = "Varışa Kalan: Hesaplanıyor...";
        el('reqBtn').classList.remove('hidden');
        el('cancelReqBtn').classList.add('hidden');
    }

    function resetDriverUI() {
        if (offerTimer) clearInterval(offerTimer);
        finishingRide = false;
        rideStarted = false;
        activeRideId = "";
        showChat(false);
        el('driverChatMessages').innerHTML = '';
        if (markers.passenger) { map.removeLayer(markers.passenger); delete markers.passenger; }
        assignedPickup = null;
        assignedDropoff = null;
        clearRoutes();

        el('driverOfferBox').innerHTML = "";
        el('driverSOSBtn').classList.add('hidden');
        el('driverNavigationBox').classList.add('hidden');
        el('arrivalBtn').classList.add('hidden');
        el('arrivalBtn').disabled = false;
        el('arrivalBtn').innerText = "KONUMA VARDIM";
        el('codeVerifyBox').classList.add('hidden');
        el('codeVerifyInput').value = "";
        el('driverCancelOrFinishBtn').classList.add('hidden');
        el('driverOnlineToggle').checked = true;
        toggleDriverStatus(true);
        el('driverStatusText').innerText = "GPS konumu otomatik güncelleniyor. Yolcu bekleniyor...";
    }

    function handleServerEvent(data) {
        if (data.type === "ERROR") {
            if (sosSending) finishSOSRequest(false, data.message || "Sunucu SOS isteğini kabul etmedi.");
            else if (data.message) alert(data.message);
            return;
        }
        if (data.type === "AUTH_REQUIRED") { alert(data.message || 'Önce yolcu hesabınıza giriş yapın.'); toggleProfileMenu(true); }
        if (data.type === "NO_DRIVERS") {
            el('pStatus').innerText = "YAKINDA AKTİF SÜRÜCÜ YOK";
            rideRequested = false;
            el('pickupInput').disabled = false;
            el('dropoffInput').disabled = false;
            el('reqBtn').classList.remove('hidden');
            el('cancelReqBtn').classList.add('hidden');
        }

        if (data.type === "RIDE_OFFER" && isDriverLoggedIn) {
            playBeep(880, 'square', 400);
            let timeLeft = 32;
            assignedPickup = data.pickup;
            assignedDropoff = data.dropoff;
            calculatedFare = Number(data.fare) || calculatedFare;

            el('driverStatusText').innerText = "Yeni Yolculuk İsteği Var!";
            el('driverOfferBox').innerHTML = `
                <div class="info-card" style="border: 1px solid #ffb300;">
                    <div class="info-title" style="color:#b78103">SÜRE: <span id="timer">${timeLeft}</span>s</div>
                    <div class="info-val">Yolcu: ${esc(data.passengerName || 'Yolcu')}</div>
                    <div class="info-val">Yolcu puanı: ${Number(data.passengerRatingCount || 0) ? `★ ${Number(data.passengerRatingAverage || 0).toFixed(2)} / 5 (${Number(data.passengerRatingCount)} değerlendirme)` : 'Henüz değerlendirilmemiş'}</div>
                    <div class="info-val">Ücret: ${Number(data.fare) || 150} TL</div>
                    <div class="btn-group">
                        <button class="action-btn danger-btn" onclick="respondOffer('REJECT')">Reddet</button>
                        <button class="action-btn driver-btn" onclick="respondOffer('ACCEPT')">Kabul Et</button>
                    </div>
                </div>
            `;
            if (offerTimer) clearInterval(offerTimer);
            offerTimer = setInterval(() => {
                timeLeft--;
                const tm = el('timer');
                if(tm) tm.innerText = timeLeft;
                if(timeLeft <= 0) {
                    clearInterval(offerTimer);
                    el('driverOfferBox').innerHTML = `<div class="info-card">Süre doldu.</div>`;
                }
            }, 1000);
            drawRoute(data.pickup, data.dropoff);
            if (driverCoords) drawDriverRoute(driverCoords, data.pickup);
        }

        if (data.type === "OFFER_TIMEOUT") {
            if (offerTimer) clearInterval(offerTimer);
            el('driverOfferBox').innerHTML = `<div class="info-card">Teklif süresi doldu.</div>`;
        }

        if (data.type === "OFFER_EXPIRED_OR_REJECTED") {
            if (!isDriverLoggedIn) {
                el('pStatus').innerText = "İSTEK REDDEDİLDİ";
                rideRequested = false;
                el('reqBtn').classList.remove('hidden');
                el('cancelReqBtn').classList.add('hidden');
            }
        }

        if (data.type === "PROFILE_DATA") {
            if (data.role === 'driver') {
                const avg = Number(data.ratingAverage || 0);
                el('driverRatingValue').innerText = avg ? `★ ${avg.toFixed(2)} / 5` : '★ -- / 5';
                el('driverRatingCount').innerText = `${data.ratingCount || 0} değerlendirme`;
                renderHistory('driverHistory', data.history || [], 'driver');
            } else {
                renderHistory('passengerHistory', data.history || [], 'passenger');
                el('passengerProfileAverage').innerText = data.ratingCount ? `★ ${Number(data.ratingAverage).toFixed(2)} / 5` : '★ -- / 5'; el('passengerProfileCount').innerText = data.ratingCount ? `${data.ratingCount} sürücü değerlendirmesi` : 'Henüz sürücü değerlendirmesi yok';
            }
        }
        if (data.type === "PASSENGER_RATING_SAVED") {
            passengerRatingSubmitting = false;
            el('passengerRatingModal').classList.add('hidden');
            el('passengerRatingComment').value = '';
            passengerRatingRideId = '';
            send({type:"GET_PROFILE", role:"driver"});
            alert('Yolcu değerlendirmeniz kaydedildi.');
        }
        if (data.type === "PASSENGER_RATING_ERROR") {
            passengerRatingSubmitting = false;
            alert(data.message || 'Yolcu değerlendirmesi kaydedilemedi.');
        }
        if (data.type === "DRIVER_RATING_UPDATE") {
            el('driverRatingValue').innerText = `★ ${Number(data.ratingAverage || 0).toFixed(2)} / 5`;
            el('driverRatingCount').innerText = `${data.ratingCount || 0} değerlendirme`;
        }

        if (data.type === "RATING_SAVED") {
            ratingSubmitted = true;
            ratingSubmitting = false;
            el('ratingComment').value = "";
            el('ratingModal').classList.add('hidden');
            currentDriverName = "";
            currentDriverPhone = "";
            completedRideId = "";
            send({type:"GET_PROFILE", role:"passenger"});
            alert("Değerlendirmeniz kaydedildi. Teşekkür ederiz!");
        }

        if (data.type === "RATING_ERROR") {
            ratingSubmitting = false;
            alert(data.message || "Değerlendirme kaydedilemedi.");
        }

        if (data.type === "RIDE_FINISHED") {
            playBeep(1000, 'sine', 400);
            if (!isDriverLoggedIn) {
                const completedDriverName = data.driverName || currentDriverName || "Lion sürücüsü";
                currentDriverPhone = data.driverPhone || currentDriverPhone;
                completedRideId = data.rideId || "";
                ratingSubmitted = false;
                // Yolcu ekranını hemen serbest bırak; puanlama penceresi yeni yolculuğu engellemesin.
                resetPassengerUI();
                el('ratingModalDriverName').innerText = `${completedDriverName} ile yolculuğunuz tamamlandı.`;
                setRating(5);
                el('ratingModal').classList.remove('hidden');
                send({type:"GET_PROFILE", role:"passenger"});
            } else {
                completedPassengerId = data.passengerId || '';
                passengerRatingRideId = data.rideId || '';
                passengerRatingSubmitting = false;
                const passengerName = data.passengerName || 'Yolcu';
                resetDriverUI();
                el('passengerRatingTarget').innerText = `${passengerName} için değerlendirme yapın.`;
                setPassengerRating(5);
                el('passengerRatingModal').classList.remove('hidden');
                send({type:"GET_PROFILE", role:"driver"});
            }
        }

        if (data.type === "RIDE_FINISH_ERROR") {
            finishingRide = false;
            const btn = el('driverCancelOrFinishBtn');
            btn.disabled = false;
            btn.innerText = "Yolculuğu Bitir";
            alert(data.message || "Yolculuk şu anda bitirilemedi. Lütfen tekrar deneyin.");
        }

        if (data.type === "RIDE_CANCELLED") {
            playBeep(300, 'sawtooth', 300);
            alert("Yolculuk iptal edildi.");
            if (!isDriverLoggedIn) {
                resetPassengerUI();
            } else if (isDriverLoggedIn) {
                resetDriverUI();
            }
        }

        if (data.type === "RIDE_MATCHED") {
            playBeep(700, 'sine', 300);
            if (offerTimer) clearInterval(offerTimer);
            currentDriverName = data.driverName || "Sürücü";
            currentDriverPhone = data.driverPhone || "";
            activeRideId = data.rideId || activeRideId;
            el('passengerChatMessages').innerHTML = '';
            el('driverChatMessages').innerHTML = '';
            showChat(true);

            if (!isDriverLoggedIn) {
                el('pStatus').innerText = "Sürücü Yolda";
                el('pStatus').className = "status-badge st-matched";
                el('passengerActiveRideBox').classList.add('hidden');
                el('rideDetailsCard').classList.add('hidden');
                el('reqBtn').classList.add('hidden');
                el('cancelReqBtn').classList.remove('hidden');

                el('passengerMatchCard').classList.remove('hidden');
                el('matchTitle').innerText = "EŞLEŞTİ - SÜRÜCÜ YOLDA";
                el('matchDriverName').innerText = `Sürücü: ${currentDriverName}`;
                el('matchCode').innerText = data.verificationCode || "----";
            } else if (isDriverLoggedIn) {
                el('driverSOSBtn').classList.remove('hidden');
                el('driverOfferBox').innerHTML = `<div class="info-card">Müşteri ile eşleştiniz. Ücret: ${calculatedFare} TL</div>`;
                el('driverStatusText').innerText = "Yolcuya doğru gidiliyor...";
                el('arrivalBtn').disabled = false;
                el('arrivalBtn').classList.remove('hidden');

                const mapsBtn = el('googleMapsNavBtn');
                mapsBtn.href = `https://www.google.com/maps/dir/?api=1&destination=${assignedPickup[0]},${assignedPickup[1]}&travelmode=driving`;
                mapsBtn.innerText = "Google Maps ile Yolcuya Git";
                el('driverNavigationBox').classList.remove('hidden');
                if (driverCoords) drawDriverRoute(driverCoords, assignedPickup);

                const cancelBtn = el('driverCancelOrFinishBtn');
                cancelBtn.innerText = "İptal Et";
                cancelBtn.classList.remove('hidden');
            }
        }

        if (data.type === "DRIVER_ARRIVED") {
            playBeep(950, 'triangle', 400);
            if (!isDriverLoggedIn) {
                el('pStatus').innerText = "SÜRÜCÜ GELDİ";
                el('matchTitle').innerText = "SÜRÜCÜ KONUMDA!";
                el('passengerMatchCard').classList.add('arrived');
                el('matchHint').innerText = "Güvenlik kodunuzu sürücüye bildirin.";
            } else if (isDriverLoggedIn) {
                el('arrivalBtn').classList.add('hidden');
                el('arrivalBtn').disabled = false;
                el('codeVerifyBox').classList.remove('hidden');
                el('driverStatusText').innerText = "Yolcu konuma varıldı. Kodu girin...";
            }
        }

        if (data.type === "WRONG_CODE") {
            playBeep(250, 'sawtooth', 300);
            alert("Hatalı kod!");
        }

        // KOD DOĞRU GİRİLDİĞİNDE YOLCULUK BAŞLADI EKRANI
        if (data.type === "RIDE_STARTED") {
            playBeep(1000, 'sine', 500);
            rideStarted = true;

            if (!isDriverLoggedIn) {
                el('pStatus').innerText = "Yolculuk Devam Ediyor";
                el('pStatus').className = "status-badge st-inride";
                
                // Kod kartı dahil diğer tüm kartları gizle, SADECE "YOLCULUK BAŞLADI" kartını göster
                el('passengerActiveRideBox').classList.add('hidden');
                el('passengerMatchCard').classList.add('hidden');
                el('rideDetailsCard').classList.add('hidden');
                el('cancelReqBtn').classList.add('hidden');

                el('passengerInRideCard').classList.remove('hidden');
                el('inRideDriverName').innerText = `Sürücü: ${currentDriverName}`;
                el('inRideFare').innerText = `Toplam Tutar: ${calculatedFare}.00 TL`;
            } else if (isDriverLoggedIn) {
                el('codeVerifyBox').classList.add('hidden');
                // Doğrulama tamamlandı: sürücü panelindeki sohbet alanı artık görünmesin.
                el('driverChatBox').classList.add('hidden');
                chatReady = false;
                
                const cancelBtn = el('driverCancelOrFinishBtn');
                cancelBtn.innerText = "Yolculuğu Bitir";
                cancelBtn.classList.remove('hidden');

                el('driverStatusText').innerText = `Yolculuk Devam Ediyor. Kazanılacak Tutar: ${calculatedFare} TL`;

                const mapsBtn = el('googleMapsNavBtn');
                mapsBtn.href = `https://www.google.com/maps/dir/?api=1&destination=${assignedDropoff[0]},${assignedDropoff[1]}&travelmode=driving`;
                mapsBtn.innerText = "Google Maps ile Varış Noktasına Git";
                if (driverCoords) drawDriverRoute(driverCoords, assignedDropoff);
            }
        }

        if (data.type === "SOS_SENT") {
            finishSOSRequest(true, "Acil durum bildiriminiz yöneticiye ve yolculuğun diğer tarafına iletildi.");
        }
        if (data.type === "SOS_RECEIVED") {
            playBeep(1100, 'square', 700);
            alert('🆘 ACİL DURUM: ' + (data.message || 'Yolculuğun diğer tarafı yardım istiyor!'));
        }
        if (data.type === "CHAT_READY") {
            activeRideId = data.rideId || activeRideId;
            showChat(true);
            (data.messages || []).forEach(renderChatMessage);
        }
        if (data.type === "CHAT_MESSAGE") {
            if (data.rideId === activeRideId) renderChatMessage(data.message || {});
        }
        if (data.type === "PASSENGER_LOCATION_UPDATE" && isDriverLoggedIn) {
            const passengerPos = [data.lat, data.lng];
            if (markers.passenger) markers.passenger.setLatLng(passengerPos);
            else markers.passenger = L.marker(passengerPos, {
                icon: L.divIcon({className:'pickup-marker', iconSize:[14,14], iconAnchor:[7,7]})
            }).addTo(map).bindPopup('Yolcunun canlı konumu');
        }

        if (data.type === "DRIVER_LOCATION_UPDATE") {
            driverCoords = [data.lat, data.lng];
            if (markers.driver) {
                markers.driver.setLatLng(driverCoords);
            } else {
                markers.driver = L.marker(driverCoords, {
                    icon: L.divIcon({ className: 'driver-marker', iconSize: [14, 14], iconAnchor: [7, 7] })
                }).addTo(map).bindPopup("Lion Sürücüsü");
            }

            if (assignedPickup && !rideStarted && currentMode === 'passenger') {
                drawDriverRoute(driverCoords, assignedPickup);
            } else if (assignedDropoff && rideStarted && currentMode === 'passenger') {
                drawDriverRoute(driverCoords, assignedDropoff);
            }
        }
    }

    function respondOffer(action) {
        if (offerTimer) clearInterval(offerTimer);
        send({ type: "RESPOND_OFFER", action: action });
        if (action === 'REJECT') {
            el('driverOfferBox').innerHTML = `<div class="info-card">İstek reddedildi.</div>`;
            el('driverNavigationBox').classList.add('hidden');
        }
    }

    function verifyRideCode() {
        const val = el('codeVerifyInput').value.trim();
        if (val.length !== 4) {
            alert("Lütfen 4 haneli kodu girin!");
            return;
        }
        send({ type: "VERIFY_CODE", code: val });
    }

    async function drawRoute(start, end) {
        if (!start || !end) return;
        try {
            const res = await fetch(`https://router.project-osrm.org/route/v1/driving/${start[1]},${start[0]};${end[1]},${end[0]}?overview=full&geometries=geojson`);
            const data = await res.json();
            if (data.routes && data.routes[0]) {
                const routeObj = data.routes[0];
                const distanceKm = routeObj.distance / 1000;
                calculatedDistanceKm = distanceKm;
                const durationMin = Math.round(routeObj.duration / 60);
                
                calculatedFare = Math.max(150, Math.round(distanceKm * 30));

                el('fareDisplay').innerText = `Ücret: ${calculatedFare}.00 TL (Minimum ücret 150 TL)`;
                el('tripInfoDisplay').innerText = `Yeşil rota: ${distanceKm.toFixed(1)} km | Tahmini Süre: ${durationMin} dk`;

                const routeCoords = routeObj.geometry.coordinates.map(c => [c[1], c[0]]);
                if (routePolyline) map.removeLayer(routePolyline);
                routePolyline = L.polyline(routeCoords, { color: '#16a34a', weight: 5, opacity: 0.9 }).addTo(map).bindTooltip(`Yeşil rota - varış mesafesi: ${distanceKm.toFixed(1)} km`, {permanent:true, direction:'center', className:'route-distance-label'});
                map.fitBounds(routePolyline.getBounds(), { padding: [30, 30] });
            }
        } catch (e) {}
    }

    async function drawDriverRoute(start, end) {
        if (!start || !end) return;
        const now = Date.now();
        if (now - lastRouteFetchAt < 3000) return;
        lastRouteFetchAt = now;
        try {
            const res = await fetch(`https://router.project-osrm.org/route/v1/driving/${start[1]},${start[0]};${end[1]},${end[0]}?overview=full&geometries=geojson`);
            const data = await res.json();
            if (data.routes && data.routes[0]) {
                const routeObj = data.routes[0];
                const distKm = (routeObj.distance / 1000).toFixed(1);
                const durMin = Math.round(routeObj.duration / 60);

                if (currentMode === 'passenger') {
                    if (rideStarted) {
                        el('inRideStats').innerText = `Yeşil rota - varışa kalan: ${distKm} km | ~${durMin} dk`;
                    } else {
                        const st = el('pStatus');
                        if (st && !st.innerText.includes("GELDİ")) {
                            st.innerHTML = `Mavi rota - sürücü size geliyor: <b>${distKm} km | ~${durMin} dk</b>`;
                        }
                    }
                }

                const routeCoords = routeObj.geometry.coordinates.map(c => [c[1], c[0]]);
                if (driverRoutePolyline) map.removeLayer(driverRoutePolyline);
                driverRoutePolyline = L.polyline(routeCoords, { color: '#168bdb', weight: 5, opacity: 0.95 }).addTo(map).bindTooltip(`Mavi rota - müşteriye kalan: ${distKm} km`, {permanent:true, direction:'center', className:'route-distance-label'});
            }
        } catch (e) {}
    }
    // Duyurular: aynı tarayıcıda her duyuru kimliği yalnızca bir kez popup gösterir.
    let announcementItems = [], announcementQueue = [], activeAnnouncement = null;
    const ANNOUNCEMENT_SEEN_KEY = 'lion_seen_announcements_v1';
    function getSeenAnnouncementIds(){try{const v=JSON.parse(localStorage.getItem(ANNOUNCEMENT_SEEN_KEY)||'[]');return new Set(Array.isArray(v)?v:[]);}catch(e){return new Set();}}
    function markAnnouncementSeen(id){const seen=getSeenAnnouncementIds();seen.add(String(id));try{localStorage.setItem(ANNOUNCEMENT_SEEN_KEY,JSON.stringify(Array.from(seen).slice(-500)));}catch(e){}}
    function renderAnnouncementList(){const target=el('announcementListContent');if(!announcementItems.length){target.innerHTML='<p class="info-title">Henüz yayımlanmış duyuru yok.</p>';return;}target.innerHTML=announcementItems.map(a=>`<div class="announcement-row"><b>${esc(a.title)}</b><div class="info-title" style="margin:5px 0">${new Date(Number(a.createdAt||0)*1000).toLocaleString('tr-TR')}</div><div style="white-space:pre-wrap;font-size:.85rem;line-height:1.5">${esc(a.body)}</div></div>`).join('');}
    function openAnnouncements(){el('announcementListOverlay').classList.remove('hidden');renderAnnouncementList();loadAnnouncements(false);}
    function closeAnnouncements(){el('announcementListOverlay').classList.add('hidden');}
    function showNextAnnouncement(){if(activeAnnouncement||!announcementQueue.length)return;activeAnnouncement=announcementQueue.shift();el('announcementPopupTitle').textContent=activeAnnouncement.title;el('announcementPopupBody').textContent=activeAnnouncement.body;markAnnouncementSeen(activeAnnouncement.id);const left=announcementQueue.length;el('announcementUnreadCount').textContent=left?`(${left})`:'';el('announcementPopup').classList.remove('hidden');}
    function closeAnnouncementPopup(){el('announcementPopup').classList.add('hidden');activeAnnouncement=null;setTimeout(showNextAnnouncement,180);}
    async function loadAnnouncements(showPopups=true){try{const r=await fetch('/announcements',{cache:'no-store'});if(!r.ok)return;const d=await r.json();announcementItems=Array.isArray(d.announcements)?d.announcements:[];renderAnnouncementList();const seen=getSeenAnnouncementIds();const unseen=announcementItems.filter(a=>a&&a.id&&!seen.has(String(a.id)));el('announcementUnreadCount').textContent=unseen.length?`(${unseen.length})`:'';if(showPopups){announcementQueue=unseen.slice().reverse();showNextAnnouncement();}}catch(e){}}
    loadAnnouncements(true);
</script>
</body>
</html>
"""


# Sunucu tarafı yolculuk/teklif durumları
OFFER_TIMEOUT = 32
offer_tasks = {}
RATINGS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ratings.json")
try:
    with open(RATINGS_FILE, "r", encoding="utf-8") as _rf:
        ratings = json.load(_rf)
    if not isinstance(ratings, list):
        ratings = []
    ratings = [r for r in ratings if isinstance(r, dict)
               and str(r.get("driverPhone", "")).strip()
               and str(r.get("rideId", "")).strip()
               and str(r.get("rating", "")).isdigit()
               and 1 <= int(r["rating"]) <= 5]
except (OSError, ValueError, TypeError):
    ratings = []
HISTORY_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ride_history.json")
SOS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sos_incidents.json")
PASSENGER_RATINGS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "passenger_ratings.json")
PASSENGER_ACCOUNTS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "passenger_accounts.json")
try:
    with open(PASSENGER_ACCOUNTS_FILE, "r", encoding="utf-8") as _af:
        passenger_accounts = json.load(_af)
    if not isinstance(passenger_accounts, dict): passenger_accounts = {}
except (OSError, ValueError, TypeError): passenger_accounts = {}

def normalize_phone(value):
    digits = "".join(ch for ch in str(value or "") if ch.isdigit())
    if digits.startswith("0090"):
        digits = digits[4:]
    elif digits.startswith("90") and len(digits) == 12:
        digits = digits[2:]
    if len(digits) == 10:
        digits = "0" + digits
    return digits
def password_digest(password, salt=None):
    import hashlib, secrets
    salt = salt or secrets.token_hex(16)
    return salt, hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), 240000).hex()
def save_passenger_accounts():
    tmp=PASSENGER_ACCOUNTS_FILE+".tmp"
    with open(tmp,"w",encoding="utf-8") as f: json.dump(passenger_accounts,f,ensure_ascii=False,indent=2)
    os.replace(tmp,PASSENGER_ACCOUNTS_FILE)
def passenger_public_profile(a):
    return {"id":a["id"],"firstName":a["firstName"],"lastName":a["lastName"],"name":a["firstName"]+" "+a["lastName"],"phone":a["phone"]}

def _load_json_list(filename):
    try:
        with open(filename, "r", encoding="utf-8") as f:
            value = json.load(f)
        return value if isinstance(value, list) else []
    except (OSError, ValueError, TypeError):
        return []
ride_history = _load_json_list(HISTORY_FILE)
passenger_ratings = _load_json_list(PASSENGER_RATINGS_FILE)
sos_incidents = _load_json_list(SOS_FILE)
ANNOUNCEMENTS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "announcements.json")
announcements = [a for a in _load_json_list(ANNOUNCEMENTS_FILE) if isinstance(a, dict) and a.get("id") and a.get("title") and a.get("body")]
sos_last_sent = {}
ride_lock = asyncio.Lock()
gps_last_update = {}
http_last_request = {}

def save_ratings():
    tmp = RATINGS_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(ratings, f, ensure_ascii=False, indent=2)
    os.replace(tmp, RATINGS_FILE)

def save_json_list(filename, values):
    tmp = filename + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(values, f, ensure_ascii=False, indent=2)
    os.replace(tmp, filename)

def rating_summary(phone):
    values = [int(r["rating"]) for r in ratings if r.get("driverPhone") == phone]
    return {"ratingAverage": round(sum(values) / len(values), 2) if values else 0,
            "ratingCount": len(values)}

def passenger_rating_summary(passenger_id):
    values = [int(r["rating"]) for r in passenger_ratings if r.get("passengerId") == passenger_id]
    return {"ratingAverage": round(sum(values) / len(values), 2) if values else 0,
            "ratingCount": len(values)}

def build_profile_payload(role, identity):
    if role == "driver":
        phone = identity
        history = [dict(x) for x in ride_history if x.get("driverPhone") == phone]
        summary = rating_summary(phone)
        return {"type":"PROFILE_DATA", "role":"driver", "history":list(reversed(history[-100:])), **summary}
    pid = identity
    history = [dict(x) for x in ride_history if x.get("passengerId") == pid]
    summary = passenger_rating_summary(pid)
    return {"type":"PROFILE_DATA", "role":"passenger", "history":list(reversed(history[-100:])), **summary}

async def safe_send(ws, payload):
    if ws is None or ws.closed:
        return False
    try:
        await ws.send_json(payload)
        return True
    except Exception:
        return False

def online_drivers():
    return [d for d, info in connected_drivers.items()
            if info.get("status") == "AVAILABLE"
            and not info.get("pending_request")
            and not info.get("matchedPassenger")]

async def broadcast_stats():
    drivers_list = [
        {"id": str(id(d)), "lat": info.get("lat"), "lng": info.get("lng"), "name": info.get("name", "Sürücü"), **rating_summary(info.get("phone", ""))}
        for d, info in connected_drivers.items()
        if info.get("lat") is not None and info.get("lng") is not None
    ]
    payload = {
        "type": "STATS_UPDATE",
        "passengers": len(passengers),
        "drivers": sum(1 for info in connected_drivers.values() if info.get("status") == "AVAILABLE"),
        "driversList": drivers_list
    }
    for client in list(passengers) + list(connected_drivers):
        await safe_send(client, payload)

async def clear_offer(driver_ws):
    task = offer_tasks.pop(driver_ws, None)
    if task and task is not asyncio.current_task() and not task.done():
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)

def haversine_km(point_a, point_b):
    """İki [lat, lng] koordinatı arasındaki kuş uçuşu mesafeyi km döndürür."""
    try:
        from math import radians, sin, cos, asin, sqrt
        lat1, lon1 = map(float, point_a)
        lat2, lon2 = map(float, point_b)
        dlat, dlon = radians(lat2-lat1), radians(lon2-lon1)
        a = sin(dlat/2)**2 + cos(radians(lat1))*cos(radians(lat2))*sin(dlon/2)**2
        return 6371.0 * 2 * asin(sqrt(a))
    except (TypeError, ValueError, ZeroDivisionError):
        return float('inf')

def driver_match_score(info, pickup):
    """Düşük skor daha iyi: mesafe temel kriter, yüksek puan küçük avantaj sağlar.
    Puanı olmayan sürücüye tarafsız 3/5 varsayılır; sıfır puanlı yeni sürücü cezalandırılmaz.
    """
    driver_pos = [info.get('lat'), info.get('lng')]
    distance = haversine_km(pickup, driver_pos) if pickup and None not in driver_pos else float('inf')
    summary = rating_summary(info.get('phone', ''))
    average = float(summary.get('ratingAverage') or 3.0)
    # Her 1 puanlık rating farkı yaklaşık 1.5 km'lik öncelik farkı yaratır.
    score = distance - ((average - 3.0) * 1.5)
    return (score, distance, -average, -int(summary.get('ratingCount') or 0))

async def dispatch_next(passenger_ws):
    """En yakın ve puanı iyi sürücüye öncelik vererek sıradaki teklifi gönder."""
    if passenger_ws not in passengers:
        return
    p = passengers[passenger_ws]
    if p.get("matchedDriver"):
        return
    tried = p.setdefault("tried_drivers", set())
    candidates = [driver_ws for driver_ws in online_drivers() if driver_ws not in tried]
    pickup = p.get('pickup')
    candidates.sort(key=lambda driver_ws: driver_match_score(connected_drivers[driver_ws], pickup))
    for driver_ws in candidates:
        if driver_ws in tried:
            continue
        tried.add(driver_ws)
        code = str(random.randint(1000, 9999))
        req = {
            "passenger_ws": passenger_ws, "code": code,
            "fare": p.get("fare", 150), "pickup": p.get("pickup"),
            "dropoff": p.get("dropoff"), "driverPhone": connected_drivers[driver_ws].get("phone"),
            "driverName": connected_drivers[driver_ws].get("name"), "rideId": uuid.uuid4().hex,
            "passengerId": p.get("profile", {}).get("id", ""),
            "passengerName": p.get("profile", {}).get("name", "Yolcu"),
            "passengerPhone": p.get("profile", {}).get("phone", ""),
            **passenger_rating_summary(p.get("profile", {}).get("id", ""))
        }
        connected_drivers[driver_ws]["pending_request"] = req
        await safe_send(driver_ws, {
            "type": "RIDE_OFFER", "pickup": req["pickup"],
            "dropoff": req["dropoff"], "fare": req["fare"],
            "expiresIn": OFFER_TIMEOUT,
            "passengerName": req.get("passengerName", "Yolcu"),
            "passengerRatingAverage": req.get("ratingAverage", 0),
            "passengerRatingCount": req.get("ratingCount", 0)
        })
        async def expire(target=driver_ws, request=req):
            try:
                await asyncio.sleep(OFFER_TIMEOUT)
                info = connected_drivers.get(target)
                if info and info.get("pending_request") is request:
                    info["pending_request"] = None
                    await safe_send(target, {"type": "OFFER_TIMEOUT"})
                    await safe_send(request["passenger_ws"], {"type": "OFFER_EXPIRED_OR_REJECTED"})
                    await dispatch_next(request["passenger_ws"])
                    await broadcast_stats()
            except asyncio.CancelledError:
                raise
            finally:
                if offer_tasks.get(target) is asyncio.current_task():
                    offer_tasks.pop(target, None)
        offer_tasks[driver_ws] = asyncio.create_task(expire())
        return
    p["searching"] = False
    await safe_send(passenger_ws, {"type": "NO_DRIVERS"})

async def cancel_driver_offer(driver_ws):
    info = connected_drivers.get(driver_ws)
    if not info:
        return
    req = info.get("pending_request")
    if req:
        await clear_offer(driver_ws)
        info["pending_request"] = None
        pws = req.get("passenger_ws")
        if pws in passengers:
            await safe_send(pws, {"type": "OFFER_EXPIRED_OR_REJECTED"})
            await dispatch_next(pws)

async def release_ride(driver_ws, event="RIDE_CANCELLED", notify_driver=True):
    info = connected_drivers.get(driver_ws)
    if not info:
        return
    pws = info.get("matchedPassenger")
    event_payload = {"type": event}
    if pws in passengers:
        if event == "RIDE_FINISHED":
            p = passengers[pws]
            profile = p.get("profile", {})
            record = {
                "rideId": info.get("ride_id"), "driverPhone": info.get("phone"),
                "driverName": info.get("name"), "passengerId": profile.get("id", ""),
                "passengerName": profile.get("name", "Yolcu"), "passengerPhone": profile.get("phone", ""),
                "fare": p.get("fare", 0), "pickup": p.get("pickup"), "dropoff": p.get("dropoff"),
                "completedAt": time.time(), "driverRating": None, "passengerRating": None,
                "driverComment": "", "passengerComment": ""
            }
            ride_history.append(record)
            try:
                save_json_list(HISTORY_FILE, ride_history)
            except OSError as exc:
                ride_history.pop()
                print(f"Yolculuk geçmişi kaydedilemedi: {exc}")
            event_payload.update({"driverPhone": info.get("phone"), "driverName": info.get("name"),
                                  "rideId": info.get("ride_id"), "passengerId": profile.get("id", ""),
                                  "passengerName": profile.get("name", "Yolcu")})
            p["completed_ride"] = {
                "driverPhone": info.get("phone"), "driverName": info.get("name"),
                "rideId": info.get("ride_id"), "passengerId": profile.get("id", ""), "rated": False
            }
        passengers[pws]["matchedDriver"] = None
        await safe_send(pws, event_payload)
    info["matchedPassenger"] = None
    info["ride_id"] = None
    info["passenger_id"] = None
    info["passenger_name"] = None
    info["code"] = None
    info["ride_started"] = False
    info["status"] = "AVAILABLE" if info.get("online_before_ride", True) else "OFFLINE"
    if notify_driver:
        await safe_send(driver_ws, event_payload)

async def websocket_handler(request):
    ws = web.WebSocketResponse(heartbeat=25, max_msg_size=64 * 1024)
    await ws.prepare(request)
    try:
        async for msg in ws:
            if msg.type == web.WSMsgType.ERROR:
                break
            if msg.type != web.WSMsgType.TEXT:
                continue
            try:
                data = json.loads(msg.data)
            except (ValueError, TypeError):
                await safe_send(ws, {"type": "ERROR", "message": "Geçersiz mesaj."})
                continue
            if not isinstance(data, dict):
                continue
            mtype = data.get("type")

            if mtype == "SOS_ALERT":
                ride_id = str(data.get("rideId", ""))[:100]
                role = str(data.get("role", ""))
                if role == "passenger" and ws in passengers:
                    passenger = passengers[ws]
                    driver_ws = passenger.get("matchedDriver")
                    driver_info = connected_drivers.get(driver_ws)
                    if not driver_info or passenger.get("ride_id") != ride_id:
                        await safe_send(ws, {"type":"ERROR", "message":"SOS yalnızca eşleşmiş/aktif yolculukta kullanılabilir."})
                        continue
                    location = ([passenger.get("lat"), passenger.get("lng")]
                                if passenger.get("lat") is not None and passenger.get("lng") is not None else None)
                    if location is None:
                        try:
                            lat, lng = float(data.get("lat")), float(data.get("lng"))
                            if -90 <= lat <= 90 and -180 <= lng <= 180:
                                location = [lat, lng]
                        except (TypeError, ValueError):
                            pass
                    name = passenger.get("profile", {}).get("name", "Yolcu")
                    recipient = driver_ws
                    phone = passenger.get("profile", {}).get("phone", "")
                elif role == "driver" and ws in connected_drivers:
                    driver_info = connected_drivers[ws]
                    passenger_ws = driver_info.get("matchedPassenger")
                    if passenger_ws not in passengers or driver_info.get("ride_id") != ride_id:
                        await safe_send(ws, {"type":"ERROR", "message":"SOS yalnızca eşleşmiş/aktif yolculukta kullanılabilir."})
                        continue
                    location = ([driver_info.get("lat"), driver_info.get("lng")]
                                if driver_info.get("lat") is not None and driver_info.get("lng") is not None else None)
                    if location is None:
                        try:
                            lat, lng = float(data.get("lat")), float(data.get("lng"))
                            if -90 <= lat <= 90 and -180 <= lng <= 180:
                                location = [lat, lng]
                        except (TypeError, ValueError):
                            pass
                    name = driver_info.get("name", "Sürücü")
                    recipient = passenger_ws
                    phone = driver_info.get("phone", "")
                else:
                    await safe_send(ws, {"type":"ERROR", "message":"SOS bildirimi için geçerli yolculuk bulunamadı."})
                    continue

                now = time.time()
                cooldown_key = (ws, ride_id)
                if now - sos_last_sent.get(cooldown_key, 0) < 30:
                    await safe_send(ws, {"type":"ERROR", "message":"SOS bildirimi kısa süre önce gönderildi. Lütfen yöneticiyle iletişim kurun."})
                    continue
                incident = {
                    "id": uuid.uuid4().hex, "rideId": ride_id, "role": role,
                    "name": str(name)[:100], "phone": str(phone)[:30],
                    "message": str(data.get("message", "Acil yardım gerekiyor."))[:250],
                    "location": location, "createdAt": now, "closed": False
                }
                sos_incidents.append(incident)
                try:
                    save_json_list(SOS_FILE, sos_incidents)
                except OSError as exc:
                    sos_incidents.pop()
                    await safe_send(ws, {"type":"ERROR", "message":"SOS kaydı kaydedilemedi: " + str(exc)})
                    continue
                sos_last_sent[cooldown_key] = now
                await safe_send(ws, {"type":"SOS_SENT"})
                loc_text = f"{location[0]:.6f}, {location[1]:.6f}" if location else "Konum alınamadı"
                await safe_send(recipient, {"type":"SOS_RECEIVED", "message":f"{name} acil yardım istiyor. Konum: {loc_text}"})
                continue

            if mtype == "DRIVER_LOGIN":
                phone = str(data.get("phone", "")).strip()
                code = str(data.get("code", "")).strip()
                valid = load_drivers()
                if phone not in valid or valid[phone]["code"] != code:
                    await safe_send(ws, {"type": "LOGIN_FAILED", "message": "Hatalı telefon numarası veya özel kod!"})
                    continue
                # Aynı telefonun eski bağlantısını güvenli biçimde kapat.
                for old_ws, old_info in list(connected_drivers.items()):
                    if old_info.get("phone") == phone and old_ws is not ws:
                        await release_ride(old_ws, "RIDE_CANCELLED", False)
                        await clear_offer(old_ws)
                        connected_drivers.pop(old_ws, None)
                        await safe_send(old_ws, {"type": "SESSION_REPLACED"})
                        await old_ws.close()
                passengers.pop(ws, None)
                connected_drivers[ws] = {
                    "status": "AVAILABLE", "lat": None, "lng": None,
                    "matchedPassenger": None, "pending_request": None,
                    "code": None, "phone": phone, "name": valid[phone]["name"],
                    "ride_started": False, "online_before_ride": True
                }
                await safe_send(ws, {"type": "LOGIN_SUCCESS", "name": valid[phone]["name"], "phone": phone, "code": code, **rating_summary(phone)})
                await broadcast_stats()

            elif mtype == "REGISTER_ROLE":
                if ws not in connected_drivers and data.get("role") == "passenger":
                    passengers.setdefault(ws, {"lat": None, "lng": None, "matchedDriver": None,
                                                "pickup": None, "dropoff": None, "tried_drivers": set(), "profile": {}, "account_phone": ""})
                    await broadcast_stats()

            elif mtype == "PASSENGER_REGISTER" and ws in passengers:
                phone=normalize_phone(data.get("phone")); password=str(data.get("password","")); first_name=str(data.get("firstName","")).strip()[:40]; last_name=str(data.get("lastName","")).strip()[:40]
                if not 10<=len(phone)<=15 or not first_name or not last_name or not 8<=len(password)<=128:
                    await safe_send(ws,{"type":"PASSENGER_AUTH_ERROR","message":"Telefon, ad, soyad ve en az 8 karakterli şifre gereklidir."}); continue
                if phone in passenger_accounts:
                    await safe_send(ws,{"type":"PASSENGER_AUTH_ERROR","message":"Bu telefon numarasıyla zaten kayıt yapılmış. Lütfen giriş yapın."}); continue
                import secrets, hashlib
                salt,digest=password_digest(password); token=secrets.token_urlsafe(32)
                account={"id":uuid.uuid4().hex,"phone":phone,"firstName":first_name,"lastName":last_name,"passwordSalt":salt,"passwordHash":digest,"sessionTokenHash":hashlib.sha256(token.encode()).hexdigest(),"createdAt":time.time()}
                passenger_accounts[phone]=account
                try: save_passenger_accounts()
                except OSError as exc:
                    passenger_accounts.pop(phone,None); await safe_send(ws,{"type":"PASSENGER_AUTH_ERROR","message":"Kayıt saklanamadı: "+str(exc)}); continue
                profile=passenger_public_profile(account); passengers[ws]["profile"]=profile; passengers[ws]["account_phone"]=phone
                await safe_send(ws,{"type":"PASSENGER_AUTH_SUCCESS","token":token,"profile":profile})
            elif mtype == "PASSENGER_LOGIN" and ws in passengers:
                phone=normalize_phone(data.get("phone")); password=str(data.get("password","")); account=passenger_accounts.get(phone)
                if not account:
                    await safe_send(ws,{"type":"PASSENGER_AUTH_ERROR","message":"Bu telefon numarasıyla kayıt bulunamadı."}); continue
                _,digest=password_digest(password,account.get("passwordSalt",""))
                if not __import__("hmac").compare_digest(digest,account.get("passwordHash","")):
                    await safe_send(ws,{"type":"PASSENGER_AUTH_ERROR","message":"Telefon numarası veya şifre hatalı."}); continue
                import secrets,hashlib
                token=secrets.token_urlsafe(32);account["sessionTokenHash"]=hashlib.sha256(token.encode()).hexdigest();save_passenger_accounts()
                profile=passenger_public_profile(account);passengers[ws]["profile"]=profile;passengers[ws]["account_phone"]=phone
                await safe_send(ws,{"type":"PASSENGER_AUTH_SUCCESS","token":token,"profile":profile})
            elif mtype == "PASSENGER_TOKEN_LOGIN" and ws in passengers:
                import hashlib,hmac
                token=str(data.get("token","")); token_hash=hashlib.sha256(token.encode()).hexdigest()
                account=next((a for a in passenger_accounts.values() if hmac.compare_digest(a.get("sessionTokenHash",""),token_hash)),None)
                if not account:
                    await safe_send(ws,{"type":"PASSENGER_AUTH_ERROR","message":"Oturum geçersiz. Lütfen yeniden giriş yapın."});continue
                profile=passenger_public_profile(account);passengers[ws]["profile"]=profile;passengers[ws]["account_phone"]=account["phone"]
                await safe_send(ws,{"type":"PASSENGER_AUTH_SUCCESS","token":token,"profile":profile,"restored":True})
            elif mtype == "PASSENGER_LOGOUT" and ws in passengers:
                phone=passengers[ws].get("account_phone", "")
                account=passenger_accounts.get(phone)
                if account:
                    account.pop("sessionTokenHash", None)
                    try: save_passenger_accounts()
                    except OSError: pass
                passengers[ws]["profile"]={};passengers[ws]["account_phone"]="";await safe_send(ws,{"type":"PASSENGER_LOGOUT_SUCCESS"})
            elif mtype == "GET_PROFILE":
                role = data.get("role")
                if role == "driver" and ws in connected_drivers:
                    await safe_send(ws, build_profile_payload("driver", connected_drivers[ws].get("phone", "")))
                elif role == "passenger" and ws in passengers and passengers[ws].get("profile", {}).get("id"):
                    pid = passengers[ws]["profile"]["id"]
                    await safe_send(ws, build_profile_payload("passenger", pid))

            elif mtype == "SET_DRIVER_STATUS" and ws in connected_drivers:
                info = connected_drivers[ws]
                desired = data.get("status")
                if desired in ("AVAILABLE", "OFFLINE"):
                    # Aktif yolculuk varken çevrimdışı yapmak yolculuğu bozmaz.
                    if info.get("matchedPassenger"):
                        info["online_before_ride"] = desired == "AVAILABLE"
                    else:
                        info["status"] = desired
                    await broadcast_stats()

            elif mtype == "DRIVER_LOGOUT" and ws in connected_drivers:
                await cancel_driver_offer(ws)
                await release_ride(ws, "RIDE_CANCELLED", False)
                connected_drivers.pop(ws, None)
                await safe_send(ws, {"type": "LOGOUT_SUCCESS"})
                await broadcast_stats()

            elif mtype in ("GPS_UPDATE", "PASSENGER_LOCATION_UPDATE", "DRIVER_LOCATION_UPDATE"):
                try:
                    lat, lng = float(data.get("lat")), float(data.get("lng"))
                    if not (-90 <= lat <= 90 and -180 <= lng <= 180):
                        continue
                except (TypeError, ValueError):
                    continue
                now = time.monotonic()
                if now - gps_last_update.get(ws, 0) < 1.0:
                    continue
                gps_last_update[ws] = now
                if ws in connected_drivers:
                    info = connected_drivers[ws]
                    info["lat"], info["lng"] = lat, lng
                    pws = info.get("matchedPassenger")
                    if pws in passengers:
                        await safe_send(pws, {"type": "DRIVER_LOCATION_UPDATE", "lat": lat, "lng": lng})
                    # Sürücü konumlarını tüm bağlı kullanıcılara en fazla saniyede bir yayınla.
                    await broadcast_stats()
                elif ws in passengers:
                    p = passengers[ws]
                    p["lat"], p["lng"] = lat, lng
                    dws = p.get("matchedDriver")
                    if dws in connected_drivers:
                        await safe_send(dws, {"type": "PASSENGER_LOCATION_UPDATE", "lat": lat, "lng": lng})

            elif mtype == "RIDE_REQUEST" and ws in passengers:
                p = passengers[ws]
                if not p.get("profile", {}).get("id"):
                    await safe_send(ws,{"type":"AUTH_REQUIRED","message":"Yolculuk çağırmak için yolcu hesabınıza giriş yapın."}); continue
                if p.get("matchedDriver") or p.get("searching"):
                    continue
                pickup, dropoff = data.get("pickup"), data.get("dropoff")
                valid_coords = isinstance(pickup, list) and len(pickup) == 2 and isinstance(dropoff, list) and len(dropoff) == 2
                try:
                    if valid_coords:
                        pickup = [float(v) for v in pickup]
                        dropoff = [float(v) for v in dropoff]
                        valid_coords = all(map(lambda v: -90 <= v <= 90, [pickup[0], dropoff[0]])) and all(map(lambda v: -180 <= v <= 180, [pickup[1], dropoff[1]]))
                except (TypeError, ValueError):
                    valid_coords = False
                if not valid_coords:
                    await safe_send(ws, {"type": "ERROR", "message": "Kalkış ve varış konumu geçersiz."})
                    continue
                try:
                    fare = max(150, float(data.get("fare", 150)))
                except (TypeError, ValueError):
                    fare = 150
                p.update({"pickup": pickup, "dropoff": dropoff, "fare": round(fare),
                          "tried_drivers": set(), "searching": True})
                await dispatch_next(ws)

            elif mtype == "RESPOND_OFFER" and ws in connected_drivers:
                info = connected_drivers[ws]
                req = info.get("pending_request")
                if not req or data.get("action") not in ("ACCEPT", "REJECT"):
                    continue
                await clear_offer(ws)
                info["pending_request"] = None
                pws = req["passenger_ws"]
                if pws not in passengers or not passengers[pws].get("searching"):
                    await broadcast_stats()
                    continue
                if data["action"] == "ACCEPT":
                    p = passengers[pws]
                    p["searching"] = False
                    p["matchedDriver"] = ws
                    p["ride_id"] = req["rideId"]
                    p["chat_messages"] = []
                    p["fare"] = req["fare"]
                    info["online_before_ride"] = info.get("status") == "AVAILABLE"
                    info["status"] = "BUSY"
                    info["matchedPassenger"] = pws
                    info["code"] = req["code"]
                    info["ride_started"] = False
                    info["ride_id"] = req["rideId"]
                    info["chat_messages"] = p["chat_messages"]
                    info["passenger_id"] = req.get("passengerId", "")
                    info["passenger_name"] = req.get("passengerName", "Yolcu")
                    match = {"type": "RIDE_MATCHED", "driverLoc": [info["lat"], info["lng"]] if info["lat"] is not None else None,
                             "verificationCode": req["code"], "driverName": info["name"],
                             "driverPhone": info["phone"], "pickup": req["pickup"], "dropoff": req["dropoff"], "fare": req["fare"],
                             "rideId": req["rideId"], "passengerId": req.get("passengerId", ""),
                             "passengerName": req.get("passengerName", "Yolcu")}
                    await safe_send(ws, match)
                    await safe_send(pws, match)
                    chat_ready = {"type":"CHAT_READY", "rideId":req["rideId"], "messages":[]}
                    await safe_send(ws, chat_ready)
                    await safe_send(pws, chat_ready)
                else:
                    await safe_send(ws, {"type": "OFFER_REJECTED"})
                    await safe_send(pws, {"type": "OFFER_EXPIRED_OR_REJECTED"})
                    await dispatch_next(pws)
                await broadcast_stats()

            elif mtype == "CHAT_SEND":
                text_value = str(data.get("text", "")).strip()
                ride_id = str(data.get("rideId", ""))
                if not text_value or len(text_value) > 500:
                    await safe_send(ws, {"type":"CHAT_ERROR", "message":"Mesaj 1-500 karakter olmalıdır."})
                    continue
                if ws in passengers:
                    p = passengers[ws]
                    dws = p.get("matchedDriver")
                    if dws not in connected_drivers or p.get("ride_id") != ride_id:
                        await safe_send(ws, {"type":"CHAT_ERROR", "message":"Bu yolculuk için sohbet aktif değil."})
                        continue
                    history = p.setdefault("chat_messages", [])
                    sender_role, recipient = "passenger", dws
                elif ws in connected_drivers:
                    info = connected_drivers[ws]
                    pws = info.get("matchedPassenger")
                    if pws not in passengers or info.get("ride_id") != ride_id:
                        await safe_send(ws, {"type":"CHAT_ERROR", "message":"Bu yolculuk için sohbet aktif değil."})
                        continue
                    history = info.setdefault("chat_messages", [])
                    sender_role, recipient = "driver", pws
                else:
                    continue
                message = {"senderRole":sender_role, "text":text_value, "createdAt":time.time()}
                history.append(message)
                if len(history) > 100:
                    del history[:-100]
                packet = {"type":"CHAT_MESSAGE", "rideId":ride_id, "message":message}
                await safe_send(ws, packet)
                await safe_send(recipient, packet)

            elif mtype == "CANCEL_RIDE":
                if ws in passengers:
                    p = passengers[ws]
                    p["searching"] = False
                    dws = p.get("matchedDriver")
                    p["matchedDriver"] = None
                    if dws in connected_drivers:
                        await release_ride(dws, "RIDE_CANCELLED", True)
                    else:
                        for dws, info in list(connected_drivers.items()):
                            if (info.get("pending_request") or {}).get("passenger_ws") is ws:
                                await clear_offer(dws)
                                info["pending_request"] = None
                    await safe_send(ws, {"type": "RIDE_CANCELLED"})
                elif ws in connected_drivers:
                    await cancel_driver_offer(ws)
                    await release_ride(ws, "RIDE_CANCELLED", True)
                await broadcast_stats()

            elif mtype == "DRIVER_ARRIVED" and ws in connected_drivers:
                info = connected_drivers[ws]
                pws = info.get("matchedPassenger")
                if pws in passengers:
                    await safe_send(pws, {"type": "DRIVER_ARRIVED"})
                    await safe_send(ws, {"type": "DRIVER_ARRIVED"})

            elif mtype == "VERIFY_CODE" and ws in connected_drivers:
                info = connected_drivers[ws]
                expected = info.get("code")
                entered = str(data.get("code", "")).strip()
                pws = info.get("matchedPassenger")
                # Boş/eksik kod kesinlikle yolculuk başlatamaz.
                if not expected or not entered or len(entered) != 4 or entered != expected or pws not in passengers:
                    await safe_send(ws, {"type": "WRONG_CODE"})
                elif not info.get("ride_started"):
                    info["ride_started"] = True
                    await safe_send(ws, {"type": "RIDE_STARTED"})
                    await safe_send(pws, {"type": "RIDE_STARTED"})

            elif mtype == "FINISH_RIDE" and ws in connected_drivers:
                info = connected_drivers[ws]
                pws = info.get("matchedPassenger")
                if pws in passengers and info.get("ride_started"):
                    # Tek bir bitirme isteği aktif yolculuğu iki tarafa da kesin olarak kapatır.
                    await release_ride(ws, "RIDE_FINISHED", True)
                    await broadcast_stats()
                else:
                    await safe_send(ws, {
                        "type": "RIDE_FINISH_ERROR",
                        "message": "Aktif ve başlamış bir yolculuk bulunamadı. Sayfayı yenileyip tekrar deneyin."
                    })

            elif mtype == "RATE_DRIVER" and ws in passengers:
                p = passengers[ws]
                completed = p.get("completed_ride") or {}
                ride_id = str(data.get("rideId", ""))
                driver_phone = str(data.get("driverPhone", ""))
                passenger_id = p.get("profile", {}).get("id", "")
                matched_history = next((ride for ride in ride_history if ride.get("rideId") == ride_id
                                        and ride.get("passengerId") == passenger_id
                                        and ride.get("driverPhone") == driver_phone), None)
                try:
                    rating = int(data.get("rating"))
                except (TypeError, ValueError):
                    rating = 0
                if (not matched_history or matched_history.get("driverRating") is not None
                        or (completed and completed.get("rideId") == ride_id and completed.get("rated"))
                        or not 1 <= rating <= 5):
                    await safe_send(ws, {"type": "RATING_ERROR", "message": "Değerlendirme geçersiz veya bu yolculuk daha önce puanlanmış."})
                    continue
                comment = str(data.get("comment", ""))[:200]
                ratings.append({"rating": rating, "comment": comment,
                                "driverPhone": matched_history["driverPhone"], "driverName": matched_history["driverName"],
                                "passengerId": passenger_id,
                                "rideId": ride_id, "createdAt": time.time()})
                if matched_history:
                    matched_history["driverRating"] = rating
                    matched_history["driverComment"] = comment
                if completed.get("rideId") == ride_id:
                    completed["rated"] = True
                try:
                    save_ratings()
                    save_json_list(HISTORY_FILE, ride_history)
                except OSError as exc:
                    ratings.pop()
                    if completed.get("rideId") == ride_id:
                        completed["rated"] = False
                    if matched_history:
                        matched_history["driverRating"] = None
                        matched_history["driverComment"] = ""
                    try:
                        save_ratings()
                        save_json_list(HISTORY_FILE, ride_history)
                    except OSError:
                        pass
                    await safe_send(ws, {"type": "RATING_ERROR", "message": "Puan kaydedilemedi: " + str(exc)})
                    continue
                await safe_send(ws, {"type": "RATING_SAVED", **rating_summary(completed["driverPhone"])})
                for dws, dinfo in connected_drivers.items():
                    if dinfo.get("phone") == completed["driverPhone"]:
                        await safe_send(dws, {"type": "DRIVER_RATING_UPDATE", **rating_summary(completed["driverPhone"])})
                await broadcast_stats()

            elif mtype == "RATE_PASSENGER" and ws in connected_drivers:
                info = connected_drivers[ws]
                ride_id = str(data.get("rideId", ""))
                passenger_id = str(data.get("passengerId", ""))
                try:
                    rating = int(data.get("rating"))
                except (TypeError, ValueError):
                    rating = 0
                record = next((r for r in ride_history if r.get("rideId") == ride_id
                               and r.get("driverPhone") == info.get("phone")
                               and r.get("passengerId") == passenger_id), None)
                if not record or record.get("passengerRating") is not None or not 1 <= rating <= 5:
                    await safe_send(ws, {"type":"PASSENGER_RATING_ERROR", "message":"Değerlendirme geçersiz veya bu yolculuk daha önce puanlanmış."})
                    continue
                comment = str(data.get("comment", ""))[:200]
                passenger_ratings.append({"rating":rating, "comment":comment, "passengerId":passenger_id,
                                          "passengerName":record.get("passengerName", "Yolcu"),
                                          "driverPhone":info.get("phone"), "rideId":ride_id, "createdAt":time.time()})
                record["passengerRating"] = rating
                record["passengerComment"] = comment
                try:
                    save_json_list(PASSENGER_RATINGS_FILE, passenger_ratings)
                    save_json_list(HISTORY_FILE, ride_history)
                except OSError as exc:
                    passenger_ratings.pop()
                    record["passengerRating"] = None
                    record["passengerComment"] = ""
                    try:
                        save_json_list(PASSENGER_RATINGS_FILE, passenger_ratings)
                        save_json_list(HISTORY_FILE, ride_history)
                    except OSError:
                        pass
                    await safe_send(ws, {"type":"PASSENGER_RATING_ERROR", "message":"Değerlendirme kaydedilemedi: " + str(exc)})
                    continue
                await safe_send(ws, {"type":"PASSENGER_RATING_SAVED", **passenger_rating_summary(passenger_id)})
                await broadcast_stats()

    except Exception as exc:
        print(f"WebSocket hatası: {exc}")
    finally:
        if ws in connected_drivers:
            await cancel_driver_offer(ws)
            await release_ride(ws, "RIDE_CANCELLED", False)
            connected_drivers.pop(ws, None)
        if ws in passengers:
            p = passengers.pop(ws)
            p["searching"] = False
            dws = p.get("matchedDriver")
            if dws in connected_drivers:
                await release_ride(dws, "RIDE_CANCELLED", True)
            for dws, info in list(connected_drivers.items()):
                if (info.get("pending_request") or {}).get("passenger_ws") is ws:
                    await clear_offer(dws)
                    info["pending_request"] = None
        await broadcast_stats()
    return ws

async def handle_index(request):
    return web.Response(text=HTML_CONTENT, content_type="text/html", charset="utf-8")

async def handle_health(request):
    return web.json_response({
        "status": "ok",
        "passengers": len(passengers),
        "drivers_online": sum(1 for info in connected_drivers.values() if info.get("status") == "AVAILABLE"),
        "active_rides": sum(1 for info in connected_drivers.values() if info.get("matchedPassenger")),
        "ratings": len(ratings)
    })

async def on_cleanup(app):
    tasks = list(offer_tasks.values())
    for task in tasks:
        task.cancel()
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)

@web.middleware
async def ip_rate_limit_middleware(request, handler):
    # Aynı IP'den HTTP uç noktalarına saniyede en fazla bir istek.
    ip = request.remote or "unknown"
    now = time.monotonic()
    previous = http_last_request.get(ip, 0)
    # Ana sayfa açılışında duyuru isteği ve yönetici panelinin veri yenilemesi
    # aynı saniyeye denk gelebilir; bu salt-okunur uç noktaları hız sınırından muaf tut.
    exempt_paths = {"/ws", "/announcements", "/admin/data"}
    is_exempt = request.path in exempt_paths or request.path.startswith("/admin/announcements")
    if not is_exempt and now - previous < 1.0:
        return web.json_response({"error": "İstek sınırı: IP başına saniyede 1 istek."}, status=429)
    if not is_exempt:
        http_last_request[ip] = now
    return await handler(request)

# -------------------- GÜVENLİ YÖNETİCİ PANELİ --------------------
# Yönetici şifresi, bu Python dosyasıyla aynı klasördeki admin_password.txt
# dosyasından okunur. Dosyada ilk boş olmayan ve # ile başlamayan satır şifredir.
import secrets as _admin_secrets
import hmac as _admin_hmac
ADMIN_PASSWORD_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "admin_password.txt")

def load_admin_password():
    try:
        with open(ADMIN_PASSWORD_FILE, "r", encoding="utf-8") as password_file:
            for line in password_file:
                candidate = line.strip()
                if candidate and not candidate.startswith("#"):
                    return candidate
    except FileNotFoundError:
        pass
    except OSError as exc:
        print(f"Yönetici şifre dosyası okunamadı: {exc}")
    return ""

ADMIN_PASSWORD = load_admin_password()
ADMIN_SESSIONS = {}
ADMIN_SESSION_TTL = 8 * 60 * 60

ADMIN_HTML = r"""<!doctype html>
<html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Lion City | Yönetici</title><link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"><style>
*{box-sizing:border-box}body{margin:0;background:#f2f5f9;color:#172033;font:15px system-ui,-apple-system,Segoe UI,sans-serif}
header{background:#111b2b;color:#fff;padding:18px 22px;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
header strong{font-size:20px;letter-spacing:.4px}.wrap{max-width:1200px;margin:22px auto;padding:0 16px}.panel{background:#fff;border:1px solid #e1e7ef;border-radius:14px;padding:18px;box-shadow:0 5px 18px #18263a0b}
.login{max-width:420px;margin:10vh auto}.login h1{margin-top:0}.muted{color:#667085}.field{width:100%;padding:12px;border:1px solid #ccd5e1;border-radius:9px;font:inherit;margin:10px 0}
button{border:0;border-radius:9px;padding:10px 14px;background:#f5b323;color:#171717;font-weight:800;cursor:pointer}button.secondary{background:#334155;color:white}button:disabled{opacity:.55;cursor:wait}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin:16px 0}.metric{background:#fff;border:1px solid #e1e7ef;border-radius:13px;padding:16px}.metric small{display:block;color:#667085;font-weight:650}.metric b{font-size:27px;display:block;margin-top:5px}
.section{margin-top:16px}.section h2{font-size:17px;margin:0 0 12px}.table-wrap{overflow:auto}table{width:100%;border-collapse:collapse;min-width:620px}th,td{text-align:left;padding:10px;border-bottom:1px solid #edf0f4;font-size:13px}th{color:#667085;background:#f8fafc}
.pill{display:inline-block;padding:4px 8px;border-radius:30px;background:#e8f5ee;color:#167044;font-weight:750;font-size:12px}.pill.off{background:#eef1f5;color:#596579}.error{color:#b42318;min-height:20px}.top-actions{display:flex;gap:8px;align-items:center}.hidden{display:none!important}
#adminLiveMap{height:480px;width:100%;border-radius:12px;z-index:1}.loc-legend{display:flex;gap:14px;flex-wrap:wrap;font-size:12px;margin:8px 0}.loc-dot{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:5px}
.announce-form{display:grid;gap:9px}.announce-form input,.announce-form textarea{width:100%;padding:11px;border:1px solid #ccd5e1;border-radius:9px;font:inherit}.announce-form textarea{min-height:110px;resize:vertical}.announce-list{display:grid;gap:8px;margin-top:12px}.announce-admin-item{border:1px solid #e1e7ef;border-radius:10px;padding:11px;display:flex;justify-content:space-between;gap:12px;align-items:start}.announce-admin-item p{margin:5px 0 0;white-space:pre-wrap;color:#667085;font-size:13px}
@media(max-width:600px){header{padding:14px}.wrap{margin:14px auto}.panel{padding:13px}#adminLiveMap{height:380px}}
</style><script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script></head><body>
<header><strong>🦁 LION CITY · Yönetici Paneli</strong><div class="top-actions"><span id="updated" class="muted" style="color:#cbd5e1;font-size:12px"></span><button id="refreshBtn" class="secondary" onclick="loadData()">Yenile</button><button id="logoutBtn" class="secondary hidden" onclick="logout()">Çıkış</button></div></header>
<main class="wrap"><section id="loginPanel" class="panel login"><h1>Yönetici girişi</h1><p class="muted">Bu alan yalnızca yetkili yöneticiler içindir.</p><form id="loginForm"><input id="password" class="field" type="password" autocomplete="current-password" placeholder="Yönetici şifresi" required><button id="loginBtn" type="submit">Giriş yap</button></form><p id="loginError" class="error"></p></section>
<section id="dashboard" class="hidden"><div class="grid">
<div class="metric"><small>Bağlı yolcular</small><b id="mPassengers">0</b></div><div class="metric"><small>Çevrimiçi sürücüler</small><b id="mDrivers">0</b></div><div class="metric"><small>Aktif yolculuklar</small><b id="mActive">0</b></div><div class="metric"><small>Tamamlanan yolculuklar</small><b id="mCompleted">0</b></div><div class="metric"><small>Toplam yolculuk tutarı</small><b id="mRevenue">₺0</b></div><div class="metric"><small>Değerlendirmeler</small><b id="mRatings">0</b></div><div class="metric"><small>Kayıtlı yolcular</small><b id="mAccounts">0</b></div></div>
<div class="panel section"><h2>🗺️ Canlı konum haritası · Sürücüler ve yolcular</h2><div class="loc-legend"><span><i class="loc-dot" style="background:#1976d2"></i>Sürücü</span><span><i class="loc-dot" style="background:#e53935"></i>Yolcu</span></div><div id="adminLiveMap"></div><p class="muted" style="font-size:12px">Konumlar bağlı cihazlardan geldikçe yaklaşık 2,5 saniyede bir yenilenir. Konum izni kapalıysa kişi listelenir ancak haritada görünmez.</p></div>
<div class="panel section"><h2>📍 Bağlı kullanıcı konumları</h2><div class="table-wrap"><table><thead><tr><th>Rol</th><th>İsim</th><th>Telefon</th><th>Durum</th><th>Yolculuk</th><th>Koordinat</th><th>Harita</th></tr></thead><tbody id="locationsBody"></tbody></table></div></div>
<div class="panel section"><h2>📢 Duyuru yönetimi</h2><form id="announcementForm" class="announce-form"><input id="announcementTitle" maxlength="120" placeholder="Duyuru başlığı" required><textarea id="announcementBody" maxlength="2000" placeholder="Duyuru metni..." required></textarea><button id="announcementPublishBtn" type="submit">📢 Duyuruyu yayımla</button><div id="announcementAdminMessage" class="muted" style="font-size:12px"></div></form><div id="adminAnnouncements" class="announce-list"></div></div>
<div class="panel section"><h2>Canlı sürücüler</h2><div class="table-wrap"><table><thead><tr><th>Sürücü</th><th>Telefon</th><th>Durum</th><th>Puan</th><th>Konum</th></tr></thead><tbody id="driversBody"></tbody></table></div></div>
<div class="panel section"><h2>Son tamamlanan yolculuklar</h2><div class="table-wrap"><table><thead><tr><th>Tarih</th><th>Sürücü</th><th>Yolcu</th><th>Tutar</th><th>Sürücü puanı</th><th>Yolcu puanı</th></tr></thead><tbody id="ridesBody"></tbody></table></div></div>
<div class="panel section" id="sosSection" style="border:2px solid #c62828"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><h2 style="color:#b71c1c">🆘 ACİL DURUM BİLDİRİMLERİ</h2><button id="soundBtn" class="secondary" onclick="enableSosSound()">🔔 Sesli uyarıyı etkinleştir</button></div><div id="sosAlertBanner" class="hidden" style="background:#b71c1c;color:white;padding:12px;border-radius:9px;font-weight:900;margin:8px 0">🆘 YENİ ACİL DURUM BİLDİRİMİ!</div><div class="table-wrap"><table><thead><tr><th>Zaman</th><th>Bildiren</th><th>İsim</th><th>Telefon</th><th>Yolculuk</th><th>Konum</th><th>Harita</th></tr></thead><tbody id="sosBody"></tbody></table></div><p class="muted" style="font-size:12px">Yeni SOS kayıtlarında sesli uyarı verilir. Tarayıcı ses izni için üstteki düğmeye bir kez basın.</p></div>
<div class="panel section"><h2>Son değerlendirmeler</h2><div class="table-wrap"><table><thead><tr><th>Tarih</th><th>Sürücü</th><th>Puan</th><th>Yorum</th></tr></thead><tbody id="ratingsBody"></tbody></table></div></div>
<p class="muted" style="font-size:12px;margin:12px 2px">Panel salt okunurdur; mevcut kullanıcı/yolculuk kayıtlarını değiştirmez. Veriler mevcut kayıt dosyalarından ve anlık bağlantılardan alınır.</p></section></main>
<script>
const $=id=>document.getElementById(id);const fmtDate=v=>v?new Date(Number(v)*1000).toLocaleString('tr-TR'):'—';const esc=v=>String(v??'—').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let sosAudio=null, sosSoundEnabled=false, seenSosIds=null, sosBannerTimer=null;
let adminMap=null, adminMapMarkers=new Map(), adminMapFitted=false;
function initAdminMap(){if(adminMap||!window.L)return;adminMap=L.map('adminLiveMap').setView([39.9,32.8],6);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap'}).addTo(adminMap);setTimeout(()=>adminMap.invalidateSize(),120);}
function updateAdminMap(locations){initAdminMap();if(!adminMap)return;const active=new Set(),bounds=[];(locations||[]).forEach(x=>{if(x.lat==null||x.lng==null)return;const lat=Number(x.lat),lng=Number(x.lng);if(!Number.isFinite(lat)||!Number.isFinite(lng)||Math.abs(lat)>90||Math.abs(lng)>180)return;const key=String(x.id),role=x.role==='driver'?'driver':'passenger';active.add(key);bounds.push([lat,lng]);const color=role==='driver'?'#1976d2':'#e53935',label=role==='driver'?'SÜRÜCÜ':'YOLCU';const icon=L.divIcon({className:'',html:`<div style="background:${color};color:#fff;border:2px solid white;border-radius:18px;padding:5px 8px;font-size:10px;font-weight:900;box-shadow:0 2px 8px #0005;white-space:nowrap">${label}</div>`,iconSize:[80,28],iconAnchor:[40,14]});const popup=`<b>${esc(x.name)}</b><br>${label}<br>${esc(x.phone||'Telefon yok')}<br>${esc(x.status||'Bağlı')}<br>${lat.toFixed(6)}, ${lng.toFixed(6)}<br><a target="_blank" rel="noopener" href="https://www.google.com/maps?q=${lat},${lng}">Google Maps'te aç</a>`;let marker=adminMapMarkers.get(key);if(marker){marker.setLatLng([lat,lng]);marker.setIcon(icon);marker.setPopupContent(popup);}else{marker=L.marker([lat,lng],{icon}).addTo(adminMap).bindPopup(popup);adminMapMarkers.set(key,marker);}});for(const [key,marker] of adminMapMarkers){if(!active.has(key)){adminMap.removeLayer(marker);adminMapMarkers.delete(key);}}if(bounds.length&&!adminMapFitted){adminMap.fitBounds(bounds,{padding:[35,35],maxZoom:13});adminMapFitted=true;}}
function renderAdminAnnouncements(items){$('adminAnnouncements').innerHTML=(items||[]).slice().reverse().map(a=>`<div class="announce-admin-item"><div><b>${esc(a.title)}</b><p>${esc(a.body)}</p><small class="muted">${esc(fmtDate(a.createdAt))}</small></div><button class="secondary" onclick="deleteAnnouncement('${esc(a.id)}')">Sil</button></div>`).join('')||'<p class="muted">Henüz duyuru eklenmedi.</p>';}
async function deleteAnnouncement(id){if(!confirm('Bu duyuruyu silmek istediğinize emin misiniz?'))return;try{const r=await fetch('/admin/announcements/'+encodeURIComponent(id),{method:'DELETE'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Silinemedi');await loadData();}catch(e){alert(e.message);}}
$('announcementForm').addEventListener('submit',async e=>{e.preventDefault();$('announcementPublishBtn').disabled=true;$('announcementAdminMessage').textContent='Yayımlanıyor...';try{const r=await fetch('/admin/announcements',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:$('announcementTitle').value.trim(),body:$('announcementBody').value.trim()})});const d=await r.json();if(!r.ok)throw new Error(d.error||'Duyuru yayımlanamadı');$('announcementTitle').value='';$('announcementBody').value='';$('announcementAdminMessage').textContent='Duyuru yayımlandı. Site ziyaretçilerine ilk ziyaretlerinde gösterilecek.';await loadData();}catch(err){$('announcementAdminMessage').textContent=err.message;}finally{$('announcementPublishBtn').disabled=false;}});
function enableSosSound(){try{sosAudio=sosAudio||new(window.AudioContext||window.webkitAudioContext)();if(sosAudio.state==='suspended')sosAudio.resume();sosSoundEnabled=true;$('soundBtn').textContent='🔊 Sesli uyarı açık';beepSos()}catch(e){$('soundBtn').textContent='Ses açılamadı';}}
function beepSos(){if(!sosSoundEnabled||!sosAudio)return;const now=sosAudio.currentTime;[0,.28,.56].forEach((offset,i)=>{const osc=sosAudio.createOscillator(),gain=sosAudio.createGain();osc.type='sawtooth';osc.frequency.value=i===1?980:760;gain.gain.setValueAtTime(.0001,now+offset);gain.gain.exponentialRampToValueAtTime(.22,now+offset+.025);gain.gain.exponentialRampToValueAtTime(.0001,now+offset+.20);osc.connect(gain);gain.connect(sosAudio.destination);osc.start(now+offset);osc.stop(now+offset+.22);});}
$('loginForm').addEventListener('submit',async e=>{e.preventDefault();$('loginBtn').disabled=true;$('loginError').textContent='';try{const r=await fetch('/admin/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:$('password').value})});const d=await r.json();if(!r.ok)throw new Error(d.error||'Giriş başarısız');$('loginPanel').classList.add('hidden');$('dashboard').classList.remove('hidden');$('logoutBtn').classList.remove('hidden');$('password').value='';initAdminMap();setTimeout(()=>{if(adminMap)adminMap.invalidateSize()},180);await loadData()}catch(err){$('loginError').textContent=err.message}finally{$('loginBtn').disabled=false}});
async function loadData(){if($('dashboard').classList.contains('hidden'))return;$('refreshBtn').disabled=true;try{const r=await fetch('/admin/data',{cache:'no-store'});if(r.status===401){showLogin();return}const d=await r.json();if(!r.ok)throw new Error(d.error||'Veriler alınamadı');$('mPassengers').textContent=d.stats.connectedPassengers;$('mDrivers').textContent=d.stats.onlineDrivers;$('mActive').textContent=d.stats.activeRides;$('mCompleted').textContent=d.stats.completedRides;$('mRevenue').textContent=new Intl.NumberFormat('tr-TR',{style:'currency',currency:'TRY',maximumFractionDigits:0}).format(d.stats.totalFare);$('mRatings').textContent=d.stats.ratingCount;$('mAccounts').textContent=d.stats.passengerAccounts;
updateAdminMap(d.locations||[]);
 $('locationsBody').innerHTML=(d.locations||[]).map(x=>{const has=x.lat!=null&&x.lng!=null,coord=has?`${Number(x.lat).toFixed(5)}, ${Number(x.lng).toFixed(5)}`:'Konum bekleniyor';const link=has?`<a target="_blank" rel="noopener" href="https://www.google.com/maps?q=${encodeURIComponent(x.lat+','+x.lng)}">Haritada aç</a>`:'—';return `<tr><td>${x.role==='driver'?'Sürücü':'Yolcu'}</td><td>${esc(x.name)}</td><td>${esc(x.phone||'—')}</td><td>${esc(x.status||'Bağlı')}</td><td>${esc(x.rideId||'—')}</td><td>${esc(coord)}</td><td>${link}</td></tr>`}).join('')||'<tr><td colspan="7">Bağlı kullanıcı yok.</td></tr>';
 renderAdminAnnouncements(d.announcements||[]);
 $('driversBody').innerHTML=d.drivers.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.phone)}</td><td><span class="pill ${x.status==='OFFLINE'?'off':''}">${esc(x.statusLabel)}</span></td><td>${x.ratingCount?`★ ${Number(x.ratingAverage).toFixed(2)} (${x.ratingCount})`:'Henüz yok'}</td><td>${x.lat!=null&&x.lng!=null?`${Number(x.lat).toFixed(4)}, ${Number(x.lng).toFixed(4)}`:'—'}</td></tr>`).join('')||'<tr><td colspan="5">Şu anda bağlı sürücü yok.</td></tr>';
$('ridesBody').innerHTML=d.rides.map(x=>`<tr><td>${esc(fmtDate(x.completedAt))}</td><td>${esc(x.driverName)}</td><td>${esc(x.passengerName)}</td><td>${esc(x.fare)} ₺</td><td>${x.driverRating??'—'}</td><td>${x.passengerRating??'—'}</td></tr>`).join('')||'<tr><td colspan="6">Henüz tamamlanan yolculuk yok.</td></tr>';
$('ratingsBody').innerHTML=d.ratings.map(x=>`<tr><td>${esc(fmtDate(x.createdAt))}</td><td>${esc(x.driverName||x.driverPhone)}</td><td>★ ${esc(x.rating)}</td><td>${esc(x.comment||'—')}</td></tr>`).join('')||'<tr><td colspan="4">Henüz değerlendirme yok.</td></tr>';
const incidents=d.sos||[];const currentIds=new Set(incidents.map(x=>x.id));if(seenSosIds!==null){const fresh=incidents.filter(x=>!seenSosIds.has(x.id));if(fresh.length){beepSos();$('sosAlertBanner').classList.remove('hidden');$('sosAlertBanner').textContent='🆘 '+fresh.length+' YENİ ACİL DURUM BİLDİRİMİ! Hemen kontrol edin.';if(sosBannerTimer)clearTimeout(sosBannerTimer);sosBannerTimer=setTimeout(()=>$('sosAlertBanner').classList.add('hidden'),15000);}}
seenSosIds=currentIds;$('sosBody').innerHTML=incidents.slice().reverse().map(x=>{const loc=Array.isArray(x.location)&&x.location.length===2?`${Number(x.location[0]).toFixed(5)}, ${Number(x.location[1]).toFixed(5)}`:'Konum yok';const map=Array.isArray(x.location)&&x.location.length===2?`<a target="_blank" rel="noopener" href="https://www.google.com/maps?q=${encodeURIComponent(x.location[0]+','+x.location[1])}">Haritada aç</a>`:'—';return `<tr style="background:#fff1f0"><td>${esc(fmtDate(x.createdAt))}</td><td><b>${x.role==='driver'?'SÜRÜCÜ':'YOLCU'}</b></td><td>${esc(x.name)}</td><td>${esc(x.phone)}</td><td>${esc(x.rideId)}</td><td>${esc(loc)}</td><td>${map}</td></tr>`}).join('')||'<tr><td colspan="7">Aktif SOS kaydı bulunmuyor.</td></tr>';
$('updated').textContent='Son güncelleme: '+new Date().toLocaleTimeString('tr-TR')}catch(e){$('updated').textContent=e.message}finally{$('refreshBtn').disabled=false}}
function showLogin(){$('dashboard').classList.add('hidden');$('loginPanel').classList.remove('hidden');$('logoutBtn').classList.add('hidden')}
async function logout(){await fetch('/admin/logout',{method:'POST'});showLogin()}setInterval(loadData,2500);
</script></body></html>"""

async def handle_admin_page(request):
    return web.Response(text=ADMIN_HTML, content_type="text/html", charset="utf-8")

async def handle_admin_login(request):
    if not ADMIN_PASSWORD:
        return web.json_response({"error": "Yönetici şifresi bulunamadı. Python dosyasıyla aynı klasördeki admin_password.txt dosyasına şifrenizi yazın ve sunucuyu yeniden başlatın."}, status=503)
    try:
        payload = await request.json()
    except (ValueError, TypeError):
        payload = {}
    supplied = str(payload.get("password", ""))[:256]
    if not _admin_hmac.compare_digest(supplied, ADMIN_PASSWORD):
        return web.json_response({"error": "Yönetici şifresi hatalı."}, status=401)
    token = _admin_secrets.token_urlsafe(40)
    ADMIN_SESSIONS[token] = time.time() + ADMIN_SESSION_TTL
    response = web.json_response({"ok": True})
    response.set_cookie("lion_admin_session", token, max_age=ADMIN_SESSION_TTL,
                        httponly=True, secure=request.secure, samesite="Strict", path="/admin")
    return response

def admin_authenticated(request):
    token = request.cookies.get("lion_admin_session", "")
    expires = ADMIN_SESSIONS.get(token)
    if not token or not expires or expires < time.time():
        ADMIN_SESSIONS.pop(token, None)
        return False
    return True

async def handle_admin_data(request):
    if not admin_authenticated(request):
        return web.json_response({"error": "Oturum süresi doldu. Yeniden giriş yapın."}, status=401)
    driver_rows = []
    for info in connected_drivers.values():
        summary = rating_summary(info.get("phone", ""))
        status = info.get("status", "OFFLINE")
        driver_rows.append({"name": info.get("name", "Sürücü"), "phone": info.get("phone", ""),
                            "status": status, "statusLabel": {"AVAILABLE":"Müsait", "BUSY":"Yolculukta", "OFFLINE":"Çevrimdışı"}.get(status, status),
                            "ratingAverage": summary["ratingAverage"], "ratingCount": summary["ratingCount"],
                            "lat": info.get("lat"), "lng": info.get("lng")})
    completed = list(reversed(ride_history[-30:]))
    recent_ratings = list(reversed(ratings[-30:]))
    for item in recent_ratings:
        item.setdefault("createdAt", 0)
        item.setdefault("driverName", next((r.get("driverName") for r in ride_history if r.get("driverPhone") == item.get("driverPhone")), item.get("driverPhone", "Sürücü")))
    live_locations = []
    for driver_ws, info in connected_drivers.items():
        live_locations.append({"id": "driver-" + str(id(driver_ws)), "role": "driver",
            "name": info.get("name", "Sürücü"), "phone": info.get("phone", ""),
            "status": {"AVAILABLE":"Müsait", "BUSY":"Yolculukta", "OFFLINE":"Çevrimdışı"}.get(info.get("status"), info.get("status", "Bağlı")),
            "lat": info.get("lat"), "lng": info.get("lng"), "rideId": info.get("ride_id") or ""})
    for passenger_ws, info in passengers.items():
        profile = info.get("profile", {}) or {}
        live_locations.append({"id": "passenger-" + str(id(passenger_ws)), "role": "passenger",
            "name": profile.get("name") or "Yolcu (misafir)", "phone": profile.get("phone") or info.get("account_phone", ""),
            "status": "Yolculukta" if info.get("matchedDriver") else ("Araç arıyor" if info.get("searching") else "Bağlı"),
            "lat": info.get("lat"), "lng": info.get("lng"), "rideId": info.get("ride_id") or ""})
    stats = {"connectedPassengers": len(passengers),
             "onlineDrivers": sum(1 for d in connected_drivers.values() if d.get("status") in ("AVAILABLE", "BUSY")),
             "activeRides": sum(1 for d in connected_drivers.values() if d.get("matchedPassenger")),
             "completedRides": len(ride_history),
             "totalFare": round(sum(float(r.get("fare", 0) or 0) for r in ride_history), 2),
             "ratingCount": len(ratings) + len(passenger_ratings),
             "passengerAccounts": len(passenger_accounts),
             "totalSos": len(sos_incidents)}
    return web.json_response({"stats": stats, "drivers": driver_rows, "locations": live_locations,
                              "rides": completed, "ratings": recent_ratings,
                              "announcements": announcements, "sos": sos_incidents[-100:]})

async def handle_public_announcements(request):
    visible = [{"id": a.get("id"), "title": a.get("title"), "body": a.get("body"), "createdAt": a.get("createdAt", 0)}
               for a in announcements if a.get("published", True)]
    return web.json_response({"announcements": visible})

async def handle_admin_announcement_create(request):
    if not admin_authenticated(request):
        return web.json_response({"error": "Yönetici oturumu gerekli."}, status=401)
    try: payload = await request.json()
    except (ValueError, TypeError): payload = {}
    title = str(payload.get("title", "")).strip()[:120]
    body = str(payload.get("body", "")).strip()[:2000]
    if not title or not body:
        return web.json_response({"error": "Başlık ve duyuru metni zorunludur."}, status=400)
    item = {"id": uuid.uuid4().hex, "title": title, "body": body, "createdAt": time.time(), "published": True}
    announcements.append(item)
    try: save_json_list(ANNOUNCEMENTS_FILE, announcements)
    except OSError as exc:
        announcements.pop()
        return web.json_response({"error": "Duyuru kaydedilemedi: " + str(exc)}, status=500)
    return web.json_response({"ok": True, "announcement": item})

async def handle_admin_announcement_delete(request):
    if not admin_authenticated(request):
        return web.json_response({"error": "Yönetici oturumu gerekli."}, status=401)
    announcement_id = request.match_info.get("announcement_id", "")
    index = next((i for i, item in enumerate(announcements) if item.get("id") == announcement_id), None)
    if index is None: return web.json_response({"error": "Duyuru bulunamadı."}, status=404)
    removed = announcements.pop(index)
    try: save_json_list(ANNOUNCEMENTS_FILE, announcements)
    except OSError as exc:
        announcements.insert(index, removed)
        return web.json_response({"error": "Duyuru silinemedi: " + str(exc)}, status=500)
    return web.json_response({"ok": True})

async def handle_admin_logout(request):
    token = request.cookies.get("lion_admin_session", "")
    ADMIN_SESSIONS.pop(token, None)
    response = web.json_response({"ok": True})
    response.del_cookie("lion_admin_session", path="/admin")
    return response
# ------------------ YÖNETİCİ PANELİ SONU ------------------

app = web.Application(client_max_size=64 * 1024, middlewares=[ip_rate_limit_middleware])
app.router.add_get("/", handle_index)
app.router.add_get("/admin", handle_admin_page)
app.router.add_post("/admin/login", handle_admin_login)
app.router.add_get("/admin/data", handle_admin_data)
app.router.add_post("/admin/announcements", handle_admin_announcement_create)
app.router.add_delete("/admin/announcements/{announcement_id}", handle_admin_announcement_delete)
app.router.add_get("/announcements", handle_public_announcements)
app.router.add_post("/admin/logout", handle_admin_logout)
app.router.add_get("/health", handle_health)
app.router.add_get("/ws", websocket_handler)
app.on_cleanup.append(on_cleanup)

if __name__ == "__main__":
    print("LION CITY - Sunucu 8080 portunda çalışıyor...")
    web.run_app(app, host="0.0.0.0", port=8080)
